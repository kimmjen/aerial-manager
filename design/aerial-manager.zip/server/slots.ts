/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import { config } from './config.js';
import { getSlotMappings, updateSlotMapping, removeSlotMapping } from './mapping.js';
import { getLibraryVideo, listLibraryVideos } from './library.js';
import { getTranscodePlan, startTranscodeJob, TranscodeState } from './transcode.js';
import { triggerWallpaperAgentReload } from './wallpaper.js';
import { WallpaperSlot } from '../src/types.js';

// Predefined set of Apple's stock Lock Screen Aerials in macOS Tahoe / Sonoma
const APPLE_STOCK_AERIALS = [
  {
    uuid: 'apple-tahoe-forest',
    name: 'Sierra Tahoe Forest Morning',
    originalVideoName: 'Sierra Tahoe Pines Morning',
    category: 'Landscape',
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    size: '850 MB',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-beautiful-aerial-shot-of-a-forest-with-pinewood-trees-42517-large.mp4'
  },
  {
    uuid: 'apple-sonoma-vineyard',
    name: 'Sonoma Vineyard Morning Mist',
    originalVideoName: 'Sonoma Valley Mist',
    category: 'Landscape',
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    size: '920 MB',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-curvy-road-in-the-forest-seen-from-above-34282-large.mp4'
  },
  {
    uuid: 'apple-maui-waves',
    name: 'Maui South Coast Reef',
    originalVideoName: 'Maui Deep Shoreline',
    category: 'Ocean',
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    size: '1.2 GB',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-set-of-waves-with-intense-sunlight-and-blue-water-43315-large.mp4'
  },
  {
    uuid: 'apple-yosemite-valley',
    name: 'Yosemite Sentinel Dome Winter',
    originalVideoName: 'Yosemite Granite Snow',
    category: 'Landscape',
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    size: '760 MB',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-video-of-a-beautiful-mountain-peak-covered-in-snow-41589-large.mp4'
  },
  {
    uuid: 'apple-milky-way',
    name: 'Milky Way Galaxy Horizon',
    originalVideoName: 'Cosmic Stellar Nebula',
    category: 'Space',
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    size: '1.4 GB',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-stars-and-nebulae-in-outer-space-41981-large.mp4'
  }
];

export function initSlots(): void {
  if (!fs.existsSync(config.AERIAL_VIDEOS_DIR)) {
    fs.mkdirSync(config.AERIAL_VIDEOS_DIR, { recursive: true });
  }

  // Generate mock physical files for stock aerials if not running on macOS, so they are selectable
  if (!config.isDarwin) {
    APPLE_STOCK_AERIALS.forEach(slot => {
      const targetPath = path.join(config.AERIAL_VIDEOS_DIR, `${slot.uuid}.mov`);
      if (!fs.existsSync(targetPath)) {
        // Just write a small empty file if it's mock system
        fs.writeFileSync(targetPath, 'MOCK_OS_AERIAL_VIDEO', 'utf-8');
      }
    });
  }
}

export function listWallpaperSlots(): WallpaperSlot[] {
  initSlots();
  const mappings = getSlotMappings();
  const library = listLibraryVideos();

  return APPLE_STOCK_AERIALS.map(stock => {
    const customMapping = mappings[stock.uuid];
    const originalBackupPath = path.join(config.BACKUP_DIR, `${stock.uuid}.mov`);
    const isBackedUp = fs.existsSync(originalBackupPath);

    let activeVideoId: string | undefined = undefined;
    let videoUrl = stock.videoUrl;
    let name = stock.name;
    let resolution = stock.resolution;
    let codec = stock.codec;
    let size = stock.size;

    if (customMapping) {
      const match = library.find(v => v.uuid === customMapping.videoUuid);
      if (match) {
        activeVideoId = match.uuid;
        videoUrl = match.filepath;
        name = `${stock.name} (${match.name})`;
        resolution = match.resolution;
        codec = match.codec;
        size = `${(match.fileSize / (1024 * 1024)).toFixed(1)} MB`;
      }
    }

    return {
      uuid: stock.uuid,
      name,
      category: stock.category,
      originalVideoName: stock.originalVideoName,
      activeVideoId,
      resolution,
      codec,
      size,
      backupStatus: isBackedUp ? 'backed_up' : 'none',
      videoUrl,
    };
  });
}

export async function applyVideoToSlot(
  slotUuid: string,
  videoUuid: string,
  onProgress?: (job: any) => void
): Promise<TranscodeState> {
  initSlots();
  
  const video = getLibraryVideo(videoUuid);
  if (!video) {
    throw new Error(`Source library video not found: ${videoUuid}`);
  }

  const slot = APPLE_STOCK_AERIALS.find(s => s.uuid === slotUuid);
  if (!slot) {
    throw new Error(`Target macOS slot not found: ${slotUuid}`);
  }

  const stockFilePath = path.join(config.AERIAL_VIDEOS_DIR, `${slotUuid}.mov`);
  const backupFilePath = path.join(config.BACKUP_DIR, `${slotUuid}.mov`);

  // 1. Back up original if not already done
  if (fs.existsSync(stockFilePath) && !fs.existsSync(backupFilePath)) {
    try {
      fs.copyFileSync(stockFilePath, backupFilePath);
    } catch (err) {
      console.warn(`Failed to create original backup at ${backupFilePath}, ignoring:`, err);
    }
  }

  // 2. Transcode or Remux from library file to the macOS slot video destination
  // If it's a URL (like pre-seeded ones), we simulate or stream copy.
  const plan = getTranscodePlan(video.codec, 'HEVC');

  const job = startTranscodeJob(
    videoUuid,
    slotUuid,
    video.name,
    slot.name,
    video.codec,
    'HEVC',
    plan,
    stockFilePath
  );

  // Background trigger / stream progress
  if (onProgress) {
    const timer = setInterval(() => {
      onProgress(job);
      if (job.status === 'completed' || job.status === 'failed') {
        clearInterval(timer);
        // After completion, write slot mapping records
        if (job.status === 'completed') {
          updateSlotMapping(slotUuid, videoUuid, `${slotUuid}.mov`);
          triggerWallpaperAgentReload();
        }
      }
    }, 500);
  } else {
    // Synchronous simulated end for simple apply
    job.status = 'completed';
    job.progress = 100;
    updateSlotMapping(slotUuid, videoUuid, `${slotUuid}.mov`);
    triggerWallpaperAgentReload();
  }

  return job;
}

export function restoreSlotToDefault(slotUuid: string): boolean {
  initSlots();
  
  const slot = APPLE_STOCK_AERIALS.find(s => s.uuid === slotUuid);
  if (!slot) return false;

  const stockFilePath = path.join(config.AERIAL_VIDEOS_DIR, `${slotUuid}.mov`);
  const backupFilePath = path.join(config.BACKUP_DIR, `${slotUuid}.mov`);

  // If a backup exists, copy it back over
  if (fs.existsSync(backupFilePath)) {
    try {
      fs.copyFileSync(backupFilePath, stockFilePath);
      removeSlotMapping(slotUuid);
      triggerWallpaperAgentReload();
      return true;
    } catch (err) {
      console.error('Failed to restore file from backup:', err);
      return false;
    }
  } else {
    // If no backup was taken (because it was never replaced), just delete custom mapping
    removeSlotMapping(slotUuid);
    triggerWallpaperAgentReload();
    return true;
  }
}
