/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { exec } from 'child_process';
import { config } from './config.js';

/**
 * Triggers a reload of macOS WallpaperAgent to immediately paint the updated locks.
 */
export function triggerWallpaperAgentReload(): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!config.isDarwin) {
      console.log('[Mock macOS OS] Reloading WallpaperAgent via: killall WallpaperAgent');
      return resolve('WallpaperAgent reloaded (MOCK MODE).');
    }

    exec('killall WallpaperAgent', (err, stdout, stderr) => {
      if (err) {
        console.warn('WallpaperAgent was not running, or failed to stop:', err.message);
        return resolve(`Soft reload complete: ${err.message}`);
      }
      console.log('Successfully reloaded macOS WallpaperAgent daemon.');
      resolve(stdout || 'WallpaperAgent reloaded successfully.');
    });
  });
}

/**
 * Executes a Python script to patch macOS binary plists (Index.plist) to lock in the UUIDs.
 * This utilizes standard macOS Python capabilities directly without external packages.
 */
export function writeMacOSPlistAsset(slotUuid: string, assetID: string): Promise<string> {
  return new Promise((resolve) => {
    if (!config.isDarwin) {
      console.log(`[Mock macOS OS] Python plist patch applied slot: ${slotUuid} => ${assetID}`);
      return resolve('Mock plist update succeeded.');
    }

    // Python code to read binary plist, locate assetID elements, replace them, and write out correctly
    const pythonCode = `
import plistlib
import sys

plist_path = "${config.PLIST_PATH}"
slot_uuid = "${slotUuid}"
asset_id = "${assetID}"

try:
    with open(plist_path, 'rb') as fp:
        pl = plistlib.load(fp)
    
    # Generic macOS Index.plist patch traverser
    # Safely look for dictionary trees hosting wallpaper slots
    def patch_dict(d):
        modified = False
        for k, v in list(d.items()):
            if isinstance(v, dict):
                modified = patch_dict(v) or modified
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, dict):
                        modified = patch_dict(item) or modified
            elif k == 'assetID' and v == slot_uuid:
                d['assetID'] = asset_id
                modified = True
        return modified

    if patch_dict(pl):
        with open(plist_path, 'wb') as fp:
            plistlib.dump(pl, fp)
        print("Success")
    else:
        print("Slot not found in plist tree")
except Exception as e:
    print(f"Error: {str(e)}")
`;

    exec(`python3 -c '${pythonCode.replace(/'/g, "'\\''")}'`, (err, stdout) => {
      if (err) {
        console.error('Python plist edit failed:', err);
        return resolve(`Failed to edit plist: ${err.message}`);
      }
      resolve(stdout.trim());
    });
  });
}
