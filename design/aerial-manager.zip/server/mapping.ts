/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import { config } from './config.js';

const MAPPING_FILE = path.join(config.DATA_DIR, 'slots.json');

export interface SlotMapping {
  [slotUuid: string]: {
    videoUuid: string;
    appliedAt: string;
    originalFileBackup?: string;
  };
}

export function initMapping(): void {
  if (!fs.existsSync(config.DATA_DIR)) {
    fs.mkdirSync(config.DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(MAPPING_FILE)) {
    fs.writeFileSync(MAPPING_FILE, JSON.stringify({}, null, 2), 'utf-8');
  }
}

export function getSlotMappings(): SlotMapping {
  initMapping();
  try {
    const raw = fs.readFileSync(MAPPING_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read mappings:', err);
    return {};
  }
}

export function updateSlotMapping(slotUuid: string, videoUuid: string, originalBackupName?: string): void {
  initMapping();
  try {
    const mappings = getSlotMappings();
    mappings[slotUuid] = {
      videoUuid,
      appliedAt: new Date().toISOString(),
      originalFileBackup: originalBackupName || mappings[slotUuid]?.originalFileBackup,
    };
    fs.writeFileSync(MAPPING_FILE, JSON.stringify(mappings, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to update mapping:', err);
  }
}

export function removeSlotMapping(slotUuid: string): void {
  initMapping();
  try {
    const mappings = getSlotMappings();
    if (mappings[slotUuid]) {
      delete mappings[slotUuid];
      fs.writeFileSync(MAPPING_FILE, JSON.stringify(mappings, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Failed to remove mapping:', err);
  }
}
