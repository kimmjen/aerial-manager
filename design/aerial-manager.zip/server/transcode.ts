/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import { config } from './config.js';

const CACHE_REGISTRY_PATH = path.join(config.DATA_DIR, 'transcode-cache.json');

export interface TranscodeState {
  id: string;
  videoUuid: string;
  slotUuid: string;
  sourceName: string;
  targetName: string;
  codecSource: string;
  codecTarget: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  progress: number;
  speed: string;
  eta: string;
  command: string;
  isCached: boolean;
}

// In-memory active transcode jobs map
export const activeJobs = new Map<string, TranscodeState>();

interface CacheRegistry {
  [videoUuid: string]: {
    cachedFile: string;
    cachedAt: string;
    codec: string;
    size: number;
  };
}

function getCacheRegistry(): CacheRegistry {
  if (!fs.existsSync(config.DATA_DIR)) {
    fs.mkdirSync(config.DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(CACHE_REGISTRY_PATH)) {
    fs.writeFileSync(CACHE_REGISTRY_PATH, JSON.stringify({}, null, 2), 'utf-8');
  }

  try {
    return JSON.parse(fs.readFileSync(CACHE_REGISTRY_PATH, 'utf-8'));
  } catch (err) {
    console.error('Failed to read transcode cache registry:', err);
    return {};
  }
}

function updateCacheRegistry(videoUuid: string, cachedFile: string, codec: string, size: number): void {
  const registry = getCacheRegistry();
  registry[videoUuid] = {
    cachedFile,
    cachedAt: new Date().toISOString(),
    codec,
    size,
  };
  fs.writeFileSync(CACHE_REGISTRY_PATH, JSON.stringify(registry, null, 2), 'utf-8');
}

export function clearTranscodeCache(): void {
  const registry = getCacheRegistry();
  Object.keys(registry).forEach(uuid => {
    const filePath = path.join(config.CACHE_DIR, registry[uuid].cachedFile);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (err) {
        console.error(`Failed to delete cache file ${filePath}:`, err);
      }
    }
  });
  fs.writeFileSync(CACHE_REGISTRY_PATH, JSON.stringify({}, null, 2), 'utf-8');
}

export function getTranscodePlan(sourceCodec: string, targetCodec: string): {
  action: 'copy' | 'transcode';
  command: string;
} {
  // If native H.264 or HEVC stream, we can do a rapid lossless stream copy (remux)
  if (sourceCodec === 'HEVC' || sourceCodec === 'H.264') {
    return {
      action: 'copy',
      command: `${config.FFMPEG_PATH} -y -i input.mp4 -c:v copy -c:a copy -map 0:v -map 0:a? output.mov`
    };
  }

  // If complex compression like AV1 or ProRes, we transcode fully to HEVC with Apple native hvc1 tag for lock screen suitability
  return {
    action: 'transcode',
    command: `${config.FFMPEG_PATH} -y -i input.mkv -c:v libx265 -tag:v hvc1 -pix_fmt yuv420p -crf 22 -preset medium -c:a aac -b:a 128k output.mov`
  };
}

export function startTranscodeJob(
  videoUuid: string,
  slotUuid: string,
  sourceName: string,
  targetName: string,
  codecSource: string,
  codecTarget: string,
  plan: { action: 'copy' | 'transcode'; command: string },
  destinationPath: string
): TranscodeState {
  const jobId = `${slotUuid}-${Date.now()}`;
  const registry = getCacheRegistry();
  const cacheHit = registry[videoUuid];

  const job: TranscodeState = {
    id: jobId,
    videoUuid,
    slotUuid,
    sourceName,
    targetName,
    codecSource,
    codecTarget,
    status: 'running',
    progress: 0,
    speed: cacheHit ? 'Instant (Cache Hit)' : plan.action === 'copy' ? '12.4x (Lossless Remux)' : '1.1x (Transcoding)',
    eta: cacheHit ? '0s' : plan.action === 'copy' ? '1s' : '48s',
    command: plan.command,
    isCached: !!cacheHit,
  };

  activeJobs.set(jobId, job);

  // Background processing
  setTimeout(() => {
    try {
      if (cacheHit) {
        // Cache Hit path: extremely performant copy directly from cache
        const cacheFilePath = path.join(config.CACHE_DIR, cacheHit.cachedFile);
        if (fs.existsSync(cacheFilePath)) {
          fs.copyFileSync(cacheFilePath, destinationPath);
          job.progress = 100;
          job.status = 'completed';
          job.eta = '0s';
          return;
        }
      }

      // If no cache hit, perform copy/transcode simulation step-by-step
      let currentProgress = 0;
      const totalSteps = plan.action === 'copy' ? 3 : 15;
      const stepInterval = plan.action === 'copy' ? 150 : 350;

      const timer = setInterval(() => {
        currentProgress += Math.floor(100 / totalSteps) + 1;
        if (currentProgress >= 100) {
          currentProgress = 100;
          clearInterval(timer);
          
          // Complete Simulation: copy mock file or seed source
          // In real container, we just create a file
          fs.writeFileSync(destinationPath, `TRANSCODED_${codecTarget}_DATA_FOR_${videoUuid}`, 'utf-8');

          // Save copy of newly transcoded file in Cache to support future uses!
          const cacheFilename = `${videoUuid}-${codecTarget.toLowerCase()}.mov`;
          const cacheFilePath = path.join(config.CACHE_DIR, cacheFilename);
          try {
            fs.writeFileSync(cacheFilePath, `CACHED_${codecTarget}_DATA_FOR_${videoUuid}`, 'utf-8');
            updateCacheRegistry(videoUuid, cacheFilename, codecTarget, 12040500);
          } catch (e) {
            console.warn('Failed to cache transcode result:', e);
          }

          job.progress = 100;
          job.status = 'completed';
          job.eta = '0s';
        } else {
          job.progress = currentProgress;
          job.eta = plan.action === 'copy' 
            ? `${Math.max(1, Math.round((100 - currentProgress) / 40))}s`
            : `${Math.max(1, Math.round((100 - currentProgress) * 0.4))}s`;
        }
        activeJobs.set(jobId, job);
      }, stepInterval);

    } catch (err) {
      console.error('Job execution failed:', err);
      job.status = 'failed';
      activeJobs.set(jobId, job);
    }
  }, 100);

  return job;
}
