/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import os from 'os';
import path from 'path';

const isDarwin = os.platform() === 'darwin';

// Root working folder for mock mode or runtime storage
const PROJECT_ROOT = process.cwd();
const DATA_DIR = path.join(PROJECT_ROOT, 'data');
const BACKUP_DIR = isDarwin 
  ? path.join(os.homedir(), '.aerial-manager', 'backup')
  : path.join(DATA_DIR, 'backup');

const CACHE_DIR = isDarwin
  ? path.join(os.homedir(), '.aerial-manager', 'cache')
  : path.join(DATA_DIR, 'cache');

const LIBRARY_DIR = isDarwin
  ? path.join(os.homedir(), '.aerial-manager', 'library')
  : path.join(DATA_DIR, 'library');

const WALLPAPER_DIR = isDarwin
  ? path.join(os.homedir(), 'Library/Application Support/com.apple.wallpaper')
  : path.join(DATA_DIR, 'com.apple.wallpaper');

const AERIAL_VIDEOS_DIR = path.join(WALLPAPER_DIR, 'aerials/videos');
const PLIST_PATH = path.join(WALLPAPER_DIR, 'Store/Index.plist');

const FFMPEG_PATH = process.env.FFMPEG_PATH || 'ffmpeg';

export const config = {
  isDarwin,
  PROJECT_ROOT,
  DATA_DIR,
  BACKUP_DIR,
  CACHE_DIR,
  LIBRARY_DIR,
  WALLPAPER_DIR,
  AERIAL_VIDEOS_DIR,
  PLIST_PATH,
  FFMPEG_PATH,
};
