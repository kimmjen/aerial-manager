/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import path from 'path';

const ALLOWED_EXTENSIONS = ['.mov', '.mp4', '.m4v', '.webm', '.mkv'];

/**
 * Validates a filename to prevent path traversal and restrict extensions.
 */
export function getSafeFilename(filename: string): string {
  // Extract basename to discard any path segments
  const base = path.basename(filename);
  
  // Normalize characters: allow letters, numbers, numbers, spaces, underscores, hyphens, and dots
  const cleanBase = base.replace(/[^a-zA-Z0-9_\-\. ]/g, '_');
  
  // Enforce lowercase safe extension
  const ext = path.extname(cleanBase).toLowerCase();
  
  if (!ALLOWED_EXTENSIONS.includes(ext)) {
    throw new Error(`Forbidden file extension: ${ext}. Allowed: ${ALLOWED_EXTENSIONS.join(', ')}`);
  }
  
  return cleanBase;
}

/**
 * Validates that the target path lies fully within the allowed parent directory.
 */
export function ensurePathInDir(targetPath: string, parentDir: string): string {
  const resolvedTarget = path.resolve(targetPath);
  const resolvedParent = path.resolve(parentDir);
  
  if (!resolvedTarget.startsWith(resolvedParent)) {
    throw new Error('Path security violation: target path is outside allowed directory bounds.');
  }
  
  return resolvedTarget;
}
