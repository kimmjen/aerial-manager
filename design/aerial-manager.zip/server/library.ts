/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import { config } from './config.js';
import { getSafeFilename, ensurePathInDir } from './paths.js';
import { AerialVideo } from '../src/types.js';

// Pre-seeded library samples to ensure the app is populated right away with gorgeous content
const SEED_SAMPLES: AerialVideo[] = [
  {
    uuid: 'seed-mountain',
    name: 'Snowy Alpine Summit (4K)',
    filename: 'mixkit-alpine-snow.mp4',
    filepath: 'https://assets.mixkit.co/videos/preview/mixkit-video-of-a-beautiful-mountain-peak-covered-in-snow-41589-large.mp4',
    fileSize: 48920100,
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    duration: 18,
    addedAt: new Date(Date.now() - 500000000).toISOString(),
    thumbnailUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=500&q=80',
    isCached: true,
  },
  {
    uuid: 'seed-forest',
    name: 'Redwood Curve Aerial',
    filename: 'mixkit-redwood-drive.mp4',
    filepath: 'https://assets.mixkit.co/videos/preview/mixkit-curvy-road-in-the-forest-seen-from-above-34282-large.mp4',
    fileSize: 31200450,
    resolution: '1920x1080 (FHD)',
    codec: 'H.264',
    duration: 12,
    addedAt: new Date(Date.now() - 400000000).toISOString(),
    thumbnailUrl: 'https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&w=500&q=80',
    isCached: true,
  },
  {
    uuid: 'seed-ocean',
    name: 'Maui Deep Coral Spray',
    filename: 'mixkit-maui-blue.mp4',
    filepath: 'https://assets.mixkit.co/videos/preview/mixkit-set-of-waves-with-intense-sunlight-and-blue-water-43315-large.mp4',
    fileSize: 55430290,
    resolution: '3840x2160 (4K)',
    codec: 'HEVC',
    duration: 15,
    addedAt: new Date(Date.now() - 300000000).toISOString(),
    thumbnailUrl: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=500&q=80',
    isCached: true,
  },
  {
    uuid: 'seed-cityscape',
    name: 'Tokyo Neon Grid Timelapse',
    filename: 'mixkit-tokyo-neon.mp4',
    filepath: 'https://assets.mixkit.co/videos/preview/mixkit-timelapse-of-a-busy-city-at-night-42217-large.mp4',
    fileSize: 72401920,
    resolution: '1920x1080 (FHD)',
    codec: 'AV1',
    duration: 35,
    addedAt: new Date(Date.now() - 200000000).toISOString(),
    thumbnailUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=500&q=80',
    isCached: false,
  },
  {
    uuid: 'seed-space',
    name: 'Atmospheric Earth Orbit',
    filename: 'mixkit-earth-orbit.mp4',
    filepath: 'https://assets.mixkit.co/videos/preview/mixkit-stars-and-nebulae-in-outer-space-41981-large.mp4',
    fileSize: 98120400,
    resolution: '3840x2160 (4K)',
    codec: 'H.264',
    duration: 40,
    addedAt: new Date(Date.now() - 100000000).toISOString(),
    thumbnailUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=500&q=80',
    isCached: true,
  }
];

// In-memory catalog file backed up on disk in data/library.json to support edits
const CATALOG_PATH = path.join(config.DATA_DIR, 'library-catalog.json');

export function initLibrary(): void {
  // Ensure paths
  if (!fs.existsSync(config.DATA_DIR)) {
    fs.mkdirSync(config.DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(config.LIBRARY_DIR)) {
    fs.mkdirSync(config.LIBRARY_DIR, { recursive: true });
  }
  if (!fs.existsSync(config.BACKUP_DIR)) {
    fs.mkdirSync(config.BACKUP_DIR, { recursive: true });
  }
  if (!fs.existsSync(config.CACHE_DIR)) {
    fs.mkdirSync(config.CACHE_DIR, { recursive: true });
  }

  if (!fs.existsSync(CATALOG_PATH)) {
    fs.writeFileSync(CATALOG_PATH, JSON.stringify(SEED_SAMPLES, null, 2), 'utf-8');
  }
}

export function listLibraryVideos(): AerialVideo[] {
  initLibrary();
  try {
    const raw = fs.readFileSync(CATALOG_PATH, 'utf-8');
    const catalog: AerialVideo[] = JSON.parse(raw);
    
    // Scan library directory for physically uploaded files too
    const physicalFiles = fs.readdirSync(config.LIBRARY_DIR);
    physicalFiles.forEach(file => {
      const fullPath = path.join(config.LIBRARY_DIR, file);
      const stat = fs.statSync(fullPath);
      
      // If we don't have this catalogued, add it
      const alreadyInCatalog = catalog.some(v => v.filename === file);
      if (!alreadyInCatalog) {
        const ext = path.extname(file).toLowerCase();
        let guessedCodec: AerialVideo['codec'] = 'Unknown';
        if (ext === '.mp4' || ext === '.mov') guessedCodec = 'H.264';
        if (ext === '.webm') guessedCodec = 'HEVC';
        
        catalog.push({
          uuid: `upload-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          name: path.basename(file, ext).replace(/_/g, ' '),
          filename: file,
          filepath: `/api/library/stream/${file}`, // streamed node endpoint
          fileSize: stat.size,
          resolution: '1920x1080 (FHD)',
          codec: guessedCodec,
          duration: 30, // guessed
          addedAt: stat.birthtime.toISOString(),
          thumbnailUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=500&q=80',
          isCached: true,
        });
      }
    });

    // Save actual updated state
    fs.writeFileSync(CATALOG_PATH, JSON.stringify(catalog, null, 2), 'utf-8');
    return catalog;
  } catch (err) {
    console.error('Failed to list library:', err);
    return SEED_SAMPLES;
  }
}

export function getLibraryVideo(uuid: string): AerialVideo | undefined {
  const library = listLibraryVideos();
  return library.find(v => v.uuid === uuid);
}

export function renameLibraryVideo(uuid: string, newName: string): boolean {
  initLibrary();
  try {
    const raw = fs.readFileSync(CATALOG_PATH, 'utf-8');
    const catalog: AerialVideo[] = JSON.parse(raw);
    const video = catalog.find(v => v.uuid === uuid);
    if (!video) return false;

    video.name = newName;
    fs.writeFileSync(CATALOG_PATH, JSON.stringify(catalog, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Rename failed:', err);
    return false;
  }
}

export function deleteLibraryVideo(uuid: string): boolean {
  initLibrary();
  try {
    const raw = fs.readFileSync(CATALOG_PATH, 'utf-8');
    const catalog: AerialVideo[] = JSON.parse(raw);
    const idx = catalog.findIndex(v => v.uuid === uuid);
    if (idx === -1) return false;

    const video = catalog[idx];
    catalog.splice(idx, 1);
    fs.writeFileSync(CATALOG_PATH, JSON.stringify(catalog, null, 2), 'utf-8');

    // If it's a local file inside config.LIBRARY_DIR, delete it physically
    if (video.filename) {
      const fullPath = path.join(config.LIBRARY_DIR, video.filename);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
    }
    return true;
  } catch (err) {
    console.error('Delete failed:', err);
    return false;
  }
}

export function addUploadedVideo(video: AerialVideo): void {
  initLibrary();
  try {
    const raw = fs.readFileSync(CATALOG_PATH, 'utf-8');
    const catalog: AerialVideo[] = JSON.parse(raw);
    catalog.push(video);
    fs.writeFileSync(CATALOG_PATH, JSON.stringify(catalog, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to add uploaded catalog:', err);
  }
}
