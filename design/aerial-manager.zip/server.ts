/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { config } from './server/config.js';
import { 
  listLibraryVideos, 
  renameLibraryVideo, 
  deleteLibraryVideo, 
  addUploadedVideo,
  initLibrary 
} from './server/library.js';
import { 
  listWallpaperSlots, 
  applyVideoToSlot, 
  restoreSlotToDefault,
  initSlots
} from './server/slots.js';
import { activeJobs, clearTranscodeCache } from './server/transcode.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Support large uploads for video streams
  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  // Initialize paths
  initLibrary();
  initSlots();

  // API 1: Fetch overall system configurations and settings
  app.get('/api/settings', (req, res) => {
    try {
      const activeLibrary = listLibraryVideos();
      const activeSlots = listWallpaperSlots();
      
      // Calculate cache size
      let cacheSize = 0;
      if (fs.existsSync(config.CACHE_DIR)) {
        const cacheFiles = fs.readdirSync(config.CACHE_DIR);
        cacheFiles.forEach(file => {
          const stats = fs.statSync(path.join(config.CACHE_DIR, file));
          cacheSize += stats.size;
        });
      }

      res.json({
        isDarwin: config.isDarwin,
        ffmpegPath: config.FFMPEG_PATH,
        paths: {
          libraryDir: config.LIBRARY_DIR,
          backupDir: config.BACKUP_DIR,
          cacheDir: config.CACHE_DIR,
          wallpaperDir: config.WALLPAPER_DIR
        },
        stats: {
          libraryCount: activeLibrary.length,
          slotsCount: activeSlots.length,
          cacheBytes: cacheSize
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 2: Fetch video library elements
  app.get('/api/library', (req, res) => {
    try {
      const videos = listLibraryVideos();
      res.json(videos);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 3: Upload video (via base64 chunks for reliability and dependency safety)
  app.post('/api/library/upload', async (req, res) => {
    try {
      const { name, filename, base64 } = req.body;
      if (!name || !filename || !base64) {
        return res.status(400).json({ error: 'Missing name, filename or base64 data.' });
      }

      const safeFilename = filename.replace(/[^a-zA-Z0-9_\-\. ]/g, '_');
      const targetPath = path.join(config.LIBRARY_DIR, safeFilename);

      // Convert and write file
      const buffer = Buffer.from(base64, 'base64');
      fs.writeFileSync(targetPath, buffer);

      const ext = path.extname(safeFilename).toLowerCase();
      let codec: 'HEVC' | 'H.264' | 'AV1' | 'ProRes' | 'Unknown' = 'H.264';
      if (ext === '.webm') codec = 'AV1';
      if (ext === '.mov') codec = 'HEVC';

      const videoUuid = `user-${Date.now()}`;
      const newVideo = {
        uuid: videoUuid,
        name: name,
        filename: safeFilename,
        filepath: `/api/library/stream/${safeFilename}`,
        fileSize: buffer.length,
        resolution: '1920x1080 (FHD)',
        codec,
        duration: 25,
        addedAt: new Date().toISOString(),
        thumbnailUrl: 'https://images.unsplash.com/photo-1574267432553-4b4628081c31?auto=format&fit=crop&w=500&q=80',
        isCached: true
      };

      addUploadedVideo(newVideo);
      res.json({ success: true, video: newVideo });
    } catch (err: any) {
      console.error('Upload API failure:', err);
      res.status(500).json({ error: err.message });
    }
  });

  // API 4: Rename library item
  app.post('/api/library/rename', (req, res) => {
    try {
      const { uuid, name } = req.body;
      if (!uuid || !name) {
        return res.status(400).json({ error: 'Missing uuid or name' });
      }
      const success = renameLibraryVideo(uuid, name);
      if (!success) {
        return res.status(404).json({ error: 'Video not found' });
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 5: Delete library item
  app.delete('/api/library', (req, res) => {
    try {
      const { uuid } = req.query;
      if (!uuid || typeof uuid !== 'string') {
        return res.status(400).json({ error: 'Missing library UUID in query' });
      }
      const success = deleteLibraryVideo(uuid);
      if (!success) {
        return res.status(404).json({ error: 'Video not found or deletion failed' });
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 6: Stream/Retrieve uploaded file
  app.get('/api/library/stream/:filename', (req, res) => {
    try {
      const { filename } = req.params;
      const targetFile = path.join(config.LIBRARY_DIR, filename);
      if (!fs.existsSync(targetFile)) {
        return res.status(404).json({ error: 'File not found' });
      }
      const stat = fs.statSync(targetFile);
      const range = req.headers.range;
      
      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;
        const chunksize = (end - start) + 1;
        const file = fs.createReadStream(targetFile, { start, end });
        const head = {
          'Content-Range': `bytes ${start}-${end}/${stat.size}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': 'video/mp4',
        };
        res.writeHead(206, head);
        file.pipe(res);
      } else {
        const head = {
          'Content-Length': stat.size,
          'Content-Type': 'video/mp4',
        };
        res.writeHead(200, head);
        fs.createReadStream(targetFile).pipe(res);
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 7: Fetch wall slots board
  app.get('/api/slots', (req, res) => {
    try {
      const slots = listWallpaperSlots();
      res.json(slots);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 8: Apply video mapping to a slot
  app.post('/api/slots/apply', async (req, res) => {
    try {
      const { slotUuid, videoUuid } = req.body;
      if (!slotUuid || !videoUuid) {
        return res.status(400).json({ error: 'Missing slotUuid or videoUuid' });
      }

      const job = await applyVideoToSlot(slotUuid, videoUuid);
      res.json({ success: true, job });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 9: Restore slot from backup
  app.post('/api/slots/restore', (req, res) => {
    try {
      const { slotUuid } = req.body;
      if (!slotUuid) {
        return res.status(400).json({ error: 'Missing slotUuid' });
      }

      const success = restoreSlotToDefault(slotUuid);
      if (!success) {
        return res.status(500).json({ error: 'Restore operation failed.' });
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 10: Query list of active transcode processes
  app.get('/api/slots/jobs', (req, res) => {
    try {
      const jobs = Array.from(activeJobs.values());
      res.json(jobs);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API 11: Wipe cache library clean
  app.post('/api/slots/cache/clear', (req, res) => {
    try {
      clearTranscodeCache();
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite Integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // SPA Fallback
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Aerial Manager Server] Online at http://0.0.0.0:${PORT}`);
  });
}

startServer();
