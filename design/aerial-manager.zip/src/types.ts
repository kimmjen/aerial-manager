/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AerialVideo {
  uuid: string;
  name: string;
  filename: string;
  filepath: string;
  fileSize: number; // in bytes
  resolution: string; // e.g., "3840x2160 (4K)"
  codec: 'HEVC' | 'H.264' | 'AV1' | 'ProRes' | 'Unknown';
  duration: number; // in seconds
  addedAt: string;
  thumbnailUrl?: string;
  isCached?: boolean;
}

export interface WallpaperSlot {
  uuid: string; // File UUID in macOS (e.g. "a5b821f0-928d-4f11-bef2-efdf9a8cd4af")
  name: string; // Display name, e.g. "Tahoe Forest Evening" or "Maui Coast"
  category: string; // e.g., "Landscape", "Earth", "Space", "Cityscape"
  activeVideoId?: string; // UUID of applied custom video, if any
  originalVideoName: string; // Apple's original video name
  resolution: string;
  codec: string;
  size: string; // e.g. "420 MB"
  lastApplied?: string;
  backupStatus: 'backed_up' | 'none' | 'restored';
  isPlaying?: boolean;
  videoUrl: string; // path or stream
}

export interface TranscodeJob {
  id: string;
  videoUuid: string;
  slotUuid: string;
  sourceName: string;
  targetName: string;
  codecSource: string;
  codecTarget: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  progress: number; // 0 to 100
  speed: string; // e.g. "1.8x"
  eta: string; // e.g. "24s"
  command: string; // ffmpeg command line string for nerd feedback
  isCached: boolean;
}

export interface Settings {
  libraryDirs: string[];
  backupDir: string;
  cacheDir: string;
  ffmpegPath: string;
  isDarwin: boolean;
}
