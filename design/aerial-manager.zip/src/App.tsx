/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Laptop, 
  Layers, 
  Cpu, 
  CheckCircle2, 
  Sparkles,
  RefreshCw,
  Bell,
  X,
  Monitor,
  Video,
  Check,
  FolderOpen,
  Info,
  Trash2,
  HardDrive,
  UploadCloud,
  ChevronRight,
  Search,
  RotateCcw,
  Clock,
  Play,
  Settings as SettingsIcon,
  AlertCircle
} from 'lucide-react';

import { AerialVideo, WallpaperSlot, TranscodeJob, Settings } from './types.js';

interface Toast {
  id: string;
  type: 'success' | 'info' | 'error';
  message: string;
  description?: string;
}

export default function App() {
  const [videos, setVideos] = useState<AerialVideo[]>([]);
  const [slots, setSlots] = useState<WallpaperSlot[]>([]);
  const [jobs, setJobs] = useState<TranscodeJob[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  
  const [selectedSlot, setSelectedSlot] = useState<WallpaperSlot | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [isInitializing, setIsInitializing] = useState(true);

  // Navigation: 홈 (home) vs 비디오 (videos)
  const [activeTab, setActiveTab] = useState<'home' | 'videos'>('home');

  // Search/Filters for target slots
  const [slotSearch, setSlotSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Custom' | 'Landscape' | 'Earth' | 'Space'>('All');

  // New video upload file variables
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Time ticker state for iMac simulator clock overlay
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatHoursMinutes = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const getWeekDayMonthDay = (date: Date) => {
    return date.toLocaleDateString('ko-KR', { weekday: 'long', month: 'long', day: 'numeric' });
  };

  // Fetch API payloads
  const fetchData = async () => {
    try {
      const [resVideos, resSlots, resJobs, resSettings] = await Promise.all([
        fetch('/api/library'),
        fetch('/api/slots'),
        fetch('/api/slots/jobs'),
        fetch('/api/settings')
      ]);

      if (resVideos.ok && resSlots.ok && resJobs.ok && resSettings.ok) {
        const vData = await resVideos.json();
        const sData = await resSlots.json();
        const jData = await resJobs.json();
        const settsData = await resSettings.json();

        setVideos(vData);
        setSlots(sData);
        setJobs(jData);
        setSettings(settsData);

        // Keep selection synced or choose first
        if (sData.length > 0) {
          setSelectedSlot(prev => {
            const match = sData.find((s: WallpaperSlot) => s.uuid === prev?.uuid);
            return match || sData[0];
          });
        }
      }
    } catch (err) {
      console.error('Data loading error:', err);
    } finally {
      setIsInitializing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // background transcode status polling
  useEffect(() => {
    const isTranscoding = jobs.some(j => j.status === 'running');
    if (!isTranscoding) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/slots/jobs');
        if (res.ok) {
          const updatedJobs = await res.json();
          setJobs(updatedJobs);

          const anyDone = updatedJobs.some((newJob: TranscodeJob) => {
            const oldJob = jobs.find(o => o.id === newJob.id);
            return oldJob && oldJob.status === 'running' && newJob.status !== 'running';
          });

          if (anyDone) {
            fetchData();
            addToast('success', '스크린세이버 적용 성공!', '새 코덱 변환과 파일 대체 맵핑 과정이 완료되어 맥에 즉각 반영되었습니다.');
          }
        }
      } catch (err) {
        console.error('Poll jobs error:', err);
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [jobs]);

  // Toast Helpers
  const addToast = (type: Toast['type'], message: string, description?: string) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, type, message, description }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Action: apply custom video to target slot
  const handleApplyVideo = async (slotUuid: string, videoUuid: string) => {
    const targetSlot = slots.find(s => s.uuid === slotUuid);
    const targetVideo = videos.find(v => v.uuid === videoUuid);
    if (!targetSlot || !targetVideo) return;

    addToast('info', '배탕화면 비디오 매핑 개시...', `'${targetVideo.name}' 비디오를 틈새 슬롯에 맞춥니다.`);

    try {
      const res = await fetch('/api/slots/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotUuid, videoUuid })
      });

      if (res.ok) {
        const result = await res.json();
        if (result.job) {
          if (result.job.isCached) {
            addToast('success', '즉시 교체 연동 완료 (캐시)', '이전에 연산 완료된 최적화 영상 소스를 바로 연결하였습니다.');
          } else if (targetVideo.codec === 'HEVC' || targetVideo.codec === 'H.264') {
            addToast('success', '순정 고배율 비디오 무손실 복사 완료', '코덱 변환 없이 원본 비디오 그대로 즉각 매핑 오버레이 하였습니다.');
          } else {
            addToast('info', '실시간 비디오 트랜스코딩 작업 생성', '대응 불가능한 형식의 영상 규격이므로 백그라운드 변환을 후속 실행합니다.');
          }
        }
        await fetchData();
      } else {
        addToast('error', '대체 매핑 연산 실패', '시스템 쓰기 잠금 및 스토리지 가용 여부를 체크해 주세요.');
      }
    } catch (err: any) {
      addToast('error', '시스템 에러', err.message);
    }
  };

  // Action: restore target slot back to raw pristine Apple video
  const handleRestoreSlot = async (slotUuid: string) => {
    const targetSlot = slots.find(s => s.uuid === slotUuid);
    if (!targetSlot) return;

    addToast('info', '순정 오리지널 복구 진입...', '정품 사본 이미지 매핑을 초기 조율합니다.');

    try {
      const res = await fetch('/api/slots/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotUuid })
      });

      if (res.ok) {
        addToast('success', '순정 Apple 기본 비디오 복원 성공!', '정품 오리지널 배경화면 루핑 에셋 복원이 완료되어 갱신되었습니다.');
        await fetchData();
      } else {
        addToast('error', '복원 실패', '정품 백업 사본이 감지되지 않거나 복원 실패했습니다.');
      }
    } catch (err: any) {
      addToast('error', '복원 처리 중 오류', err.message);
    }
  };

  // Action: add custom clip with bases64 buffer
  const handleUploadFile = async (name: string, filename: string, base64: string) => {
    try {
      const res = await fetch('/api/library/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, filename, base64 })
      });

      if (res.ok) {
        addToast('success', '동영상 보관소 등록 성공', `'${name}' 영상이 성공적으로 추가되었습니다.`);
        await fetchData();
      } else {
        addToast('error', '업로드 에러', '업로드 제약 용량을 초과하였거나 시스템 메모리가 부족합니다.');
      }
    } catch (err: any) {
      addToast('error', '영상 전송 오류', err.message);
    }
  };

  // Action: Delete user customized clip
  const handleDeleteVideo = async (uuid: string) => {
    try {
      const res = await fetch(`/api/library?uuid=${uuid}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        addToast('info', '비디오 보관소에서 제거됨', '해당 보관 파일 및 디스크 내 고화질 원본 파일이 완전 삭감 처리 되었습니다.');
        await fetchData();
      } else {
        addToast('error', '보관 해제 오류', '현재 실행중인 비디오 렌더러 점유로 인해 소거할 수 없습니다.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Clean raw caches
  const handleClearCache = async () => {
    try {
      const res = await fetch('/api/slots/cache/clear', { method: 'POST' });
      if (res.ok) {
        addToast('success', '임시 디바이스 컴파일 캐시 초기화', '저장 장치 공간을 클린 보정하였습니다.');
        await fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handle standard HTML input change of file upload
  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setIsUploading(true);
      setUploadProgress(15);

      const reader = new FileReader();
      reader.onload = async (ev) => {
        setUploadProgress(50);
        const urlStr = ev.target?.result as string;
        if (!urlStr) {
          setIsUploading(false);
          return;
        }

        const b64Data = urlStr.split(',')[1];
        setUploadProgress(80);

        try {
          const tidyName = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
          await handleUploadFile(tidyName, file.name, b64Data);
          setUploadProgress(100);
          setTimeout(() => {
            setIsUploading(false);
            setUploadProgress(0);
          }, 400);
        } catch {
          setIsUploading(false);
          setUploadProgress(0);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Extract label inside parenthesis: "Tahoe (My Movie)" -> "My Movie"
  const getCustomLabel = (slotName: string) => {
    const match = slotName.match(/\((.*?)\)/);
    return match ? match[1] : null;
  };

  // Filter Target Slots
  const filteredSlots = slots.filter(slot => {
    const customLabel = getCustomLabel(slot.name);
    const matchesSearch = slot.name.toLowerCase().includes(slotSearch.toLowerCase()) || 
                          slot.category.toLowerCase().includes(slotSearch.toLowerCase());
    
    if (categoryFilter === 'All') return matchesSearch;
    if (categoryFilter === 'Custom') return matchesSearch && !!customLabel;
    return matchesSearch && slot.category === categoryFilter;
  });

  const formatSize = (bytes: number) => {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const isTranscodingActive = jobs.some(j => j.status === 'running');
  const activeReplacementLabel = selectedSlot ? getCustomLabel(selectedSlot.name) : null;

  return (
    <div className="min-h-screen bg-[#F6F6F6] text-slate-800 flex flex-col font-sans antialiased select-none">
      
      {/* Elegantly Polished System Alert Toasts */}
      <div className="fixed top-5 right-5 z-[100] flex flex-col gap-2 w-80 max-w-full">
        {toasts.map(t => (
          <div
            key={t.id}
            className={`p-3.5 rounded-xl shadow-md border backdrop-blur-md transition-all duration-300 flex items-start gap-2.5 ${
              t.type === 'success' ? 'bg-emerald-50/95 border-emerald-200 text-emerald-800' :
              t.type === 'error' ? 'bg-red-50/95 border-red-200 text-red-800' :
              'bg-white/95 border-slate-200 text-slate-800'
            }`}
          >
            <div className="shrink-0 mt-0.5">
              <CheckCircle2 className={`w-4 h-4 ${t.type === 'success' ? 'text-emerald-500' : t.type === 'error' ? 'text-red-500' : 'text-blue-500'}`} />
            </div>
            <div className="flex-1 text-xs">
              <span className="font-bold block leading-snug">{t.message}</span>
              {t.description && <span className="text-[10px] text-slate-500 mt-1 block leading-normal">{t.description}</span>}
            </div>
            <button onClick={() => removeToast(t.id)} className="text-slate-400 hover:text-slate-600 shrink-0">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Modern Top Apple Mac Menu-Style Header */}
      <header className="bg-white border-b border-slate-200/80 px-6 py-4.5 z-20">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          
          {/* Logo Title Group */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-blue-500 to-indigo-600 rounded-xl shadow-inner flex items-center justify-center shrink-0">
              <Laptop className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-slate-900 block leading-none">
                macOS Aerial Screen Customizer
              </h1>
              <p className="text-[11px] text-slate-500 mt-1 font-medium">
                맥북 정품 에이리얼 비디오 화면 보호기를 손쉽게 커스텀 영상으로 치환하는 샌드박스 관리 도구
              </p>
            </div>
          </div>

          {/* Quick status controls */}
          <div className="flex items-center gap-2.5">
            {isTranscodingActive ? (
              <div className="bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs text-blue-700">
                <RefreshCw className="w-3.5 h-3.5 text-blue-500 animate-spin" />
                <span className="font-bold">백그라운드 변환 및 최적화 인코딩 인덱싱 중</span>
              </div>
            ) : (
              <div className="bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs text-emerald-700 font-medium">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                <span>호스트 링크가 원활하게 열려있습니다</span>
              </div>
            )}
            
            <button
              onClick={fetchData}
              title="동기화 적용 가용 여부 확인"
              className="p-2 bg-white hover:bg-slate-50 rounded-lg border border-slate-205 text-slate-500 hover:text-slate-800 transition shadow-sm"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Content Wrapper Containing Master Dashboard Grid */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col lg:flex-row z-10">
        
        {/* SIDEBAR: Simple, Minimal Left Selection Track */}
        <aside className="w-full lg:w-56 bg-white lg:border-r border-b lg:border-b-0 border-slate-200/80 flex flex-col justify-between p-5 select-none shrink-0">
          <div className="flex flex-col gap-6">
            
            {/* Quick Title indicating Sidebar limits */}
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block select-none">
              Control Menu
            </span>

            {/* Sidebar Buttons */}
            <nav className="flex flex-col gap-1" aria-label="메뉴 카테고리">
              <button
                onClick={() => setActiveTab('home')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition duration-200 ${
                  activeTab === 'home'
                    ? 'bg-blue-50 text-blue-600 border border-blue-10/20'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <Monitor className={`w-4 h-4 shrink-0 ${activeTab === 'home' ? 'text-blue-500' : 'text-slate-400'}`} />
                <span>홈 (Lock Screen)</span>
              </button>

              <button
                onClick={() => setActiveTab('videos')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition duration-200 ${
                  activeTab === 'videos'
                    ? 'bg-blue-50 text-blue-600 border border-blue-10/20'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <FolderOpen className={`w-4 h-4 shrink-0 ${activeTab === 'videos' ? 'text-blue-500' : 'text-slate-400'}`} />
                <span>비디오 보관소 (Vault)</span>
              </button>
            </nav>
          </div>

          {/* Quick Stats Summary inside Sidebar bottom */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col gap-2.5 text-[10px] text-slate-400 select-none">
            <div className="flex justify-between items-center">
              <span>바탕화면 대상 슬롯:</span>
              <span className="text-slate-700 font-bold font-mono">{slots.length}개</span>
            </div>
            <div className="flex justify-between items-center">
              <span>보관 사용자 동영상:</span>
              <span className="text-slate-700 font-bold font-mono">{videos.length}개</span>
            </div>
            <div className="flex justify-between items-center">
              <span>커스텀 지정 슬롯:</span>
              <span className="text-blue-600 font-bold font-mono">
                {slots.filter(s => getCustomLabel(s.name)).length}개
              </span>
            </div>
          </div>
        </aside>

        {/* MAIN WORKSPACE VIEW ROUTER */}
        <main className="flex-1 p-5 md:p-6 overflow-y-auto">

          {/* TAB 1: HOME WORKSPACE ("홈에서의 메인 영역은 비디오 그리고 오른쪽에는 리스트 클릭하면 메인영역이 표현되고") */}
          {activeTab === 'home' && (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start" id="home-view-grid">
              
              {/* LEFT MAIN AREA (8cols): The Video Player preview and Slot customization options */}
              <div className="xl:col-span-8 flex flex-col gap-4">
                
                {selectedSlot ? (
                  <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm flex flex-col gap-5">
                    
                    {/* Header line for the selected slot inside active view */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3.5 pb-3 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[9px] font-bold text-slate-400 uppercase font-mono bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                            {selectedSlot.category} 슬롯
                          </span>
                          {activeReplacementLabel ? (
                            <span className="text-[9px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded">
                              커스텀 적용 중
                            </span>
                          ) : (
                            <span className="text-[9px] font-bold text-slate-500 bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded">
                              기본 순정 동영상 재생 중
                            </span>
                          )}
                        </div>

                        <h2 className="text-base font-bold text-slate-900 leading-tight">
                          {selectedSlot.name.split(' (')[0]}
                        </h2>
                      </div>

                      {/* Rollback to original backup */}
                      {activeReplacementLabel && (
                        <button
                          onClick={() => handleRestoreSlot(selectedSlot.uuid)}
                          className="flex items-center gap-1.5 bg-red-50 hover:bg-red-100/70 border border-red-200 text-red-600 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>정품 순정 원본 복구</span>
                        </button>
                      )}
                    </div>

                    {/* Apple Style Visual Bezel Desktop Screensaver Simulator */}
                    <div className="relative rounded-2xl border-4 border-slate-900 bg-black aspect-video w-full overflow-hidden shadow-md group">
                      
                      {/* Original or customized video renderer */}
                      {selectedSlot.videoUrl ? (
                        <video
                          key={selectedSlot.videoUrl}
                          src={selectedSlot.videoUrl}
                          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                          autoPlay
                          loop
                          muted
                          playsInline
                        />
                      ) : (
                        <div className="absolute inset-0 bg-slate-50 flex flex-col items-center justify-center text-slate-400">
                          <RefreshCw className="w-6 h-6 animate-spin mb-1.5 text-slate-300" />
                          <span className="text-xs font-mono">연결하는 중...</span>
                        </div>
                      )}

                      {/* Glass gradient overlay */}
                      <div className="absolute inset-0 bg-black/15 group-hover:bg-black/25 transition-all duration-300 pointer-events-none" />

                      {/* iMac simulated lock screen clocks */}
                      <div className="absolute inset-0 flex flex-col justify-between p-4.5 text-white z-10 select-none pointer-events-none">
                        
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] bg-black/45 backdrop-blur-md px-2 py-0.5 rounded-full border border-white/10 font-mono tracking-wider font-semibold">
                            PREVIEW
                          </span>
                          <span className="text-[9.5px] font-semibold tracking-wide drop-shadow-md">
                            {selectedSlot.resolution}
                          </span>
                        </div>

                        <div className="flex flex-col items-center text-center -mt-2">
                          <h3 className="text-4xl sm:text-5xl font-light tracking-tight text-white drop-shadow-xl font-sans">
                            {formatHoursMinutes(time)}
                          </h3>
                          <span className="text-[10px] sm:text-[11px] font-semibold text-white/90 uppercase tracking-wider mt-1 drop-shadow-md">
                            {getWeekDayMonthDay(time)}
                          </span>
                        </div>

                        <div className="text-[8.5px] text-white/50 font-mono">
                          macOS Locking Simulator Process ID: {selectedSlot.uuid.substring(0,8)}...
                        </div>
                      </div>

                    </div>

                    {/* Real Path Details */}
                    <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-3 text-xs text-slate-500">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold block">정품 타겟 보관 경로 (Original Target File):</span>
                          <span className="font-mono text-[10.5px] text-slate-700 block truncate" title={selectedSlot.originalVideoName}>
                            {selectedSlot.originalVideoName}
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold block">현재 화질 규격 및 크기 (Codec Scale):</span>
                          <span className="font-medium text-emerald-600 block mt-0.5">
                            {selectedSlot.resolution} Format / HEVC [{selectedSlot.size}]
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Active customization interface: replacing slots with user's video */}
                    <div className="flex flex-col gap-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[11px] text-slate-400 font-black uppercase tracking-wide flex items-center gap-1.5">
                          <Video className="w-4 h-4 text-slate-400" />
                          <span>대체 적용할 고화질 비디오 지정</span>
                        </span>
                        
                        <span className="text-[10px] text-slate-500">단블럭 클릭시 스크린세이버 자동 교체 적용</span>
                      </div>

                      {videos.length === 0 ? (
                        <div className="bg-slate-50 border border-dashed border-slate-200 rounded-xl p-6.5 text-center text-slate-500">
                          <AlertCircle className="w-5 h-5 text-slate-350 mx-auto mb-1.5" />
                          <p className="text-xs font-medium">아직 사용자 커스텀 비디오를 업로드하지 않았습니다.</p>
                          <button
                            onClick={() => setActiveTab('videos')}
                            className="mt-2 text-xs text-blue-600 hover:text-blue-800 font-bold transition inline-flex items-center gap-1"
                          >
                            <span>비디오 보관소로 이동해 파일 업로드하기</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[196px] overflow-y-auto pr-1">
                          {videos.map(video => {
                            const isCurrentApplied = selectedSlot.activeVideoId === video.filename || 
                                                     selectedSlot.name.includes(`(${video.name})`);
                            
                            return (
                              <div
                                key={video.uuid}
                                onClick={() => handleApplyVideo(selectedSlot.uuid, video.uuid)}
                                className={`group p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between h-22 relative overflow-hidden ${
                                  isCurrentApplied 
                                    ? 'border-blue-500 bg-blue-50/15' 
                                    : 'border-slate-200 bg-white hover:border-slate-350 hover:bg-slate-50/20'
                                }`}
                              >
                                <div>
                                  <div className="flex items-center justify-between">
                                    <span className="text-[8px] font-black font-mono text-blue-600 bg-blue-50 px-1 rounded">
                                      {video.codec}
                                    </span>
                                    <span className="text-[8.5px] font-mono text-slate-400">
                                      {video.duration}초 · {formatSize(video.fileSize)}
                                    </span>
                                  </div>
                                  <h4 className="text-[11.5px] font-bold text-slate-800 truncate mt-1.5">
                                    {video.name}
                                  </h4>
                                </div>

                                <div className="flex justify-between items-center text-[10px] mt-1 text-slate-500">
                                  <span className="font-mono text-[8.5px] text-slate-400 truncate max-w-[130px]" title={video.filename}>
                                    {video.filename}
                                  </span>

                                  {isCurrentApplied ? (
                                    <span className="text-[9.5px] font-bold text-blue-600 flex items-center gap-1 bg-blue-100/40 px-1.5 rounded-md">
                                      <Check className="w-3 h-3" />
                                      <span>작동 중</span>
                                    </span>
                                  ) : (
                                    <span className="text-[9px] px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-600 font-extrabold group-hover:text-blue-600 group-hover:border-blue-200 transition">
                                      대체 지정
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                  </div>
                ) : (
                  <div className="aspect-video w-full rounded-2xl bg-white border border-slate-200/80 shadow-sm flex flex-col items-center justify-center text-slate-400 text-xs">
                    <Laptop className="w-8 h-8 text-slate-300 mb-2" />
                    <span>우측 리스트에서 변경할 바탕화면 슬롯을 선택해 주십시오.</span>
                  </div>
                )}

              </div>

              {/* RIGHT SLOTS LIST (4cols): List of Target Wallpaper slots */}
              <div className="xl:col-span-4 flex flex-col gap-3">
                
                {/* Search / Filter wrapper */}
                <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                  <div className="flex justify-between items-center selection:bg-transparent">
                    <span className="text-xs font-black tracking-widest text-slate-400 uppercase flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-slate-400" />
                      <span>대체 대상 슬롯 리스트</span>
                    </span>
                    <span className="text-[10px] font-bold text-slate-400 font-mono bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                      {slots.length} Targets
                    </span>
                  </div>

                  {/* Slot Search Input field */}
                  <div className="relative">
                    <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={slotSearch}
                      onChange={(e) => setSlotSearch(e.target.value)}
                      placeholder="이름 검색 (예: Maui, Valley...)"
                      className="w-full bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 rounded-xl py-2 pl-9 pr-3 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white transition"
                    />
                  </div>

                  {/* Quick Filters */}
                  <div className="flex flex-wrap gap-1">
                    {(['All', 'Custom', 'Landscape', 'Earth', 'Space'] as const).map(f => (
                      <button
                        key={f}
                        onClick={() => setCategoryFilter(f)}
                        className={`px-2 py-1 rounded-lg text-[9.5px] font-bold border transition ${
                          categoryFilter === f
                            ? 'bg-blue-500 text-white border-blue-500 shadow-sm'
                            : 'bg-white text-slate-500 border-slate-200 hover:text-slate-800 hover:bg-slate-50'
                        }`}
                      >
                        {f === 'Custom' ? '★ 교체 보정됨' : f}
                      </button>
                    ))}
                  </div>

                </div>

                {/* Main Scrollable Slots target items */}
                <div className="space-y-2 overflow-y-auto max-h-[460px] pr-1 scrollbar-thin">
                  {filteredSlots.length === 0 ? (
                    <div className="bg-white/50 border border-dashed border-slate-200 rounded-2xl p-8 text-center text-slate-400 text-xs font-medium">
                      일치하는 타겟 슬롯이 없습니다.
                    </div>
                  ) : (
                    filteredSlots.map(slot => {
                      const customLabel = getCustomLabel(slot.name);
                      const isSelected = selectedSlot?.uuid === slot.uuid;

                      return (
                        <div
                          key={slot.uuid}
                          onClick={() => setSelectedSlot(slot)}
                          className={`border p-3 rounded-xl transition duration-200 cursor-pointer flex items-center justify-between gap-3 ${
                            isSelected
                              ? 'border-blue-500 bg-blue-50/15 shadow-sm shadow-blue-50/10'
                              : 'border-slate-200 bg-white hover:border-slate-350 shadow-xs'
                          }`}
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 mb-1.5">
                              <span className="text-[8px] font-bold text-slate-400 uppercase font-mono bg-slate-100 px-1 py-0.5 rounded border border-slate-200">
                                {slot.category}
                              </span>
                              {customLabel ? (
                                <span className="text-[8px] font-extrabold text-amber-700 bg-amber-50 border border-amber-200 px-1 py-0.5 rounded">
                                  대체됨
                                </span>
                              ) : (
                                <span className="text-[8px] font-extrabold text-slate-400 bg-slate-50 px-1 py-0.5 rounded border border-slate-100">
                                  기본순정
                                </span>
                              )}
                            </div>

                            <h4 className="text-xs font-bold text-slate-800 truncate leading-snug">
                              {slot.name.split(' (')[0]}
                            </h4>

                            <p className="text-[10px] text-slate-500 truncate mt-1">
                              {customLabel ? `커스텀: ${customLabel}` : `정품: ${slot.originalVideoName}`}
                            </p>
                          </div>

                          <div className="shrink-0">
                            <ChevronRight className={`w-4 h-4 transition ${isSelected ? 'text-blue-500 translate-x-0.5' : 'text-slate-350'}`} />
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

              </div>
              
            </div>
          )}

          {/* TAB 2: VIDEOS LIBRARY WORKSPACE (Upload box, manage custom collections, codec details) */}
          {activeTab === 'videos' && (
            <div className="flex flex-col gap-5" id="library-workspace">
              
              <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm">
                
                {/* Header title */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-4">
                  <div>
                    <h2 className="text-sm font-bold tracking-tight text-slate-900 flex items-center gap-2">
                      <FolderOpen className="w-5 h-5 text-blue-500" />
                      <span>사용자 에이리얼 비디오 보관소</span>
                    </h2>
                    <p className="text-[11px] text-slate-500 mt-1 font-medium">
                      순정 화면 보호기를 치환할 영상 파일들을 등록 및 보관하거나 디바이스 용량을 보급 제어합니다.
                    </p>
                  </div>

                  <span className="text-xs bg-slate-50 border border-slate-200 text-slate-500 px-3 py-1 rounded-full font-mono font-bold shrink-0">
                    등록 영상 개수: {videos.length}개
                  </span>
                </div>

                {/* Elegant, clean White Drag & Drop Box */}
                <div className="border border-dashed border-slate-200 hover:border-blue-400 bg-slate-50 hover:bg-slate-50/50 p-6 rounded-2xl text-center relative transition duration-200">
                  <input 
                    type="file" 
                    accept="video/*" 
                    onChange={onFileChange} 
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                    disabled={isUploading}
                    ref={fileInputRef}
                  />
                  {isUploading ? (
                    <div className="flex flex-col items-center py-2">
                      <RefreshCw className="w-6 h-6 text-blue-500 animate-spin mb-2" />
                      <span className="text-xs text-slate-700 font-bold">비디오 파일 로딩 및 용량 인코딩 중...</span>
                      <div className="w-48 bg-slate-200 h-1 rounded-full mt-2 overflow-hidden">
                        <div 
                          className="bg-blue-500 h-1 transition-all" 
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center py-1 select-none">
                      <UploadCloud className="w-7 h-7 text-blue-500 mb-2" />
                      <h5 className="text-[12px] font-bold text-slate-700">
                        여기에 동영상 파일을 끌어놓거나, 클릭하여 직접 파일 업로드
                      </h5>
                      <span className="text-[10px] text-slate-400 block mt-1">
                        MP4, MKV, WebM, AV1 등 전체 영상 형식 무손실 임포트 및 HEVC 자동 실시간 트랜스코딩 연산 지원
                      </span>
                    </div>
                  )}
                </div>

                {/* Video Grids items list */}
                <div className="mt-6">
                  <span className="text-[11px] text-slate-400 font-bold block uppercase mb-3">
                    저장된 커스텀 비디오 목록
                  </span>

                  {videos.length === 0 ? (
                    <div className="bg-slate-50 border border-slate-150 rounded-2xl p-10 text-center text-slate-400 text-xs font-semibold">
                      아카이브 보관 내역이 비어 있습니다. 위 업로드 영역을 사용하여 추가해 주십시오.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {videos.map(video => {
                        const isOriginalSampleSeed = video.uuid.startsWith('seed-');
                        
                        return (
                          <div 
                            key={video.uuid}
                            className="bg-white border border-slate-200 p-3.5 rounded-xl flex flex-col justify-between hover:border-slate-300 transition duration-200 group"
                          >
                            <div className="min-w-0">
                              <div className="flex justify-between items-start gap-2">
                                <span className="text-[8.5px] font-black font-mono text-blue-600 bg-blue-50 border border-blue-100/30 px-1.5 py-0.5 rounded">
                                  {video.codec}
                                </span>
                                <span className="text-[9px] font-mono text-slate-400 shrink-0">
                                  {video.duration}초 · {formatSize(video.fileSize)}
                                </span>
                              </div>

                              <h4 className="text-xs font-bold text-slate-800 truncate mt-2 pb-0.5" title={video.name}>
                                {video.name}
                              </h4>
                              <p className="font-mono text-[9px] text-slate-400 truncate block mt-0.5" title={video.filename}>
                                {video.filename}
                              </p>
                            </div>

                            <div className="mt-4 pt-2 border-t border-slate-100 flex justify-between items-center text-[10px] text-slate-400">
                              <span className="text-[8.5px] font-mono text-slate-400 leading-none">
                                Added: {video.addedAt ? video.addedAt.substring(0, 10) : 'Pre-loaded'}
                              </span>

                              {/* Delete option if custom */}
                              {!isOriginalSampleSeed && (
                                <button
                                  onClick={() => handleDeleteVideo(video.uuid)}
                                  className="text-red-500 hover:text-red-700 font-bold transition flex items-center gap-1 px-2 py-1 rounded bg-red-50 hover:bg-red-100/60 border border-red-100 text-[9.5px]"
                                  title="고화질 가용 에셋 보류 취소 완전 소거"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span>삭제</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

              </div>

              {/* Cache clear control helper */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs">
                <div className="flex gap-2.5 items-start">
                  <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800 block">임시 트랜스코딩 캐시 회수</span>
                    <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                      대체 규격 영상(AV1, WebM 등)을 인코딩 복사하는 과정에서 소모된 물리 임시 파일 캐시들을 완전 청소함으로써 장치 여유 공간을 회복할 수 있습니다.
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleClearCache}
                  className="bg-slate-100 hover:bg-red-50 border border-slate-200 hover:border-red-200 text-slate-600 hover:text-red-600 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0"
                >
                  임시 디스크 캐시 완전 비우기
                </button>
              </div>

            </div>
          )}

        </main>

      </div>

      {/* Tidy minimal Apple Preference Style status footer */}
      <footer className="border-t border-slate-200 bg-white py-4 px-6 flex flex-col sm:flex-row justify-between items-center gap-3 text-[10.5px] text-slate-400 select-none">
        <span>macOS Dynamic Local Host Sandbox.</span>
        <div className="flex items-center gap-1.5 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-200/80 font-mono text-[9px] text-slate-500 font-semibold select-text">
          <span>Target Directory: ~/Library/Application Support/com.apple.wallpaper/Aerials/</span>
        </div>
      </footer>

    </div>
  );
}
