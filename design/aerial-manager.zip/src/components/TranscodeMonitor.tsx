/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Cpu, 
  Activity, 
  CheckCircle2, 
  XOctagon, 
  Clock, 
  Zap, 
  HardDrive,
  Trash2,
  Terminal,
  Layers
} from 'lucide-react';
import { TranscodeJob } from '../types.js';

interface TranscodeMonitorProps {
  jobs: TranscodeJob[];
  systemStats: {
    libraryCount: number;
    slotsCount: number;
    cacheBytes: number;
  } | null;
  onClearCache: () => void;
}

export default function TranscodeMonitor({ jobs, systemStats, onClearCache }: TranscodeMonitorProps) {
  const activeJobs = jobs.filter(j => j.status === 'running');
  const pastJobs = jobs.filter(j => j.status === 'completed' || j.status === 'failed');

  const formatStorage = (bytes: number) => {
    if (!bytes) return '0.0 MB';
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6" id="transcoding-monitor-hud">
      {/* HUD Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-900">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-sky-950/40 border border-sky-800/35 rounded-xl">
            <Cpu className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">Transcode & Cache Engine</h3>
            <p className="text-[10px] text-slate-500 font-medium">ffmpeg hardware mapping & cache registers</p>
          </div>
        </div>

        {/* Cache status metrics block */}
        <div className="flex items-center gap-3 bg-slate-900/60 p-2 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-2 px-1">
            <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
            <div className="text-left leading-tight">
              <span className="text-[9px] font-light text-slate-500 block">Active Cache Size</span>
              <span className="text-xs font-bold text-slate-200 font-mono">
                {systemStats ? formatStorage(systemStats.cacheBytes) : 'Scanning...'}
              </span>
            </div>
          </div>
          
          <button
            onClick={() => {
              if (confirm('Wipe complete local HEVC transcode cache? Future non-native replacements will require full transcode duration.')) {
                onClearCache();
              }
            }}
            className="bg-red-950/20 hover:bg-red-900/30 border border-red-900/20 text-red-400 hover:text-red-300 px-3 py-1.5 rounded-xl text-[10px] font-bold transition flex items-center gap-1 leading-none"
            title="Clear and free cache storage"
            id="clear-transcode-cache-btn"
          >
            <Trash2 className="w-3 h-3" />
            <span>Clear Cache</span>
          </button>
        </div>
      </div>

      {/* Real-time Task Feed */}
      <div className="mt-5">
        <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-3 select-none flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-sky-400" />
          <span>Active Pipeline Transcodes</span>
        </h4>

        {activeJobs.length === 0 ? (
          <div className="bg-slate-900/10 border border-slate-900 rounded-2xl p-6 text-center text-slate-500 text-xs">
            No active transcoding threads in progress. Ready for command assignment.
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {activeJobs.map(job => (
              <div 
                key={job.id} 
                className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl flex flex-col gap-3 relative overflow-hidden"
                id={`active-job-${job.id}`}
              >
                {/* Glow effect if encoding */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/5 rounded-full blur-3xl" />

                {/* Meta details header line */}
                <div className="flex justify-between items-start gap-3 z-10">
                  <div>
                    <span className="text-[9px] font-black text-sky-400 uppercase tracking-wide block">
                      Slot target — {job.targetName.split(' (')[0]}
                    </span>
                    <h5 className="text-xs font-extrabold text-slate-100 mt-0.5 truncate max-w-xs" title={job.sourceName}>
                      {job.sourceName}
                    </h5>
                  </div>

                  <div className="text-right flex flex-col items-end">
                    <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/30 border border-emerald-900/25 px-2 py-0.5 rounded-full select-none flex items-center gap-1">
                      <Zap className="w-3 h-3 fill-emerald-400 text-emerald-400 animate-pulse" />
                      {job.speed}
                    </span>
                    <span className="text-[9px] text-slate-500 font-mono font-light mt-1">
                      Remaining ETA: {job.eta}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full z-10">
                  <div className="flex justify-between items-center text-[10px] font-mono mb-1 text-slate-400">
                    <span>Encoding from {job.codecSource} to {job.codecTarget}</span>
                    <span className="font-bold text-white">{job.progress}%</span>
                  </div>
                  <div className="bg-slate-950 rounded-full h-2 w-full overflow-hidden border border-slate-900">
                    <div 
                      className="bg-gradient-to-r from-sky-500 to-indigo-500 h-2 rounded-full transition-all duration-300 shadow-md shadow-sky-500/20" 
                      style={{ width: `${job.progress}%` }}
                    />
                  </div>
                </div>

                {/* Geek Command Line Drawer (Terminal representation of ffmpeg syntax) */}
                <div className="bg-slate-950 border border-slate-900 rounded-xl p-2.5 font-mono text-[9px] text-slate-400 flex items-start gap-2 select-all overflow-x-auto z-10 select-none">
                  <Terminal className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                  <span className="whitespace-nowrap inline-block text-slate-300">
                    {job.command}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Historic Logs (Recent Task completion lists) */}
      <div className="mt-6 pt-5 border-t border-slate-900">
        <h4 className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-3 select-none">
          Recent Pipeline Ledger
        </h4>
        {pastJobs.length === 0 ? (
          <span className="text-[10px] text-slate-600 font-medium">No recent operations performed this session.</span>
        ) : (
          <div className="flex flex-col gap-2 max-h-36 overflow-y-auto pr-1">
            {pastJobs.map(job => (
              <div 
                key={job.id} 
                className="bg-slate-900/20 border border-slate-900 px-3.5 py-2 rounded-xl flex items-center justify-between text-[11px] leading-tight select-none"
                id={`past-job-${job.id}`}
              >
                <div className="flex items-center gap-2 pr-4 truncate">
                  {job.status === 'completed' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <XOctagon className="w-4 h-4 text-red-400 shrink-0" />
                  )}
                  <div className="truncate">
                    <span className="text-white font-bold block truncate" title={job.sourceName}>
                      {job.sourceName}
                    </span>
                    <span className="text-[9px] text-slate-500 block truncate font-mono">
                      Target: {job.targetName.split(' (')[0]}
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className={`text-[9px] font-mono font-extrabold px-2 py-0.5 rounded-full ${
                    job.isCached 
                      ? 'bg-sky-500/15 text-sky-400' 
                      : 'bg-emerald-500/10 text-emerald-400'
                  }`}>
                    {job.isCached ? 'Cache Transferred' : 'Simulated Transcoded'}
                  </span>
                  <span className="text-[9px] text-slate-500 block font-mono mt-1">Status: Success</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
