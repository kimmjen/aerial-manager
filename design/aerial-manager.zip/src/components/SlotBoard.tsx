/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  RotateCcw, 
  Layers, 
  Video, 
  HelpCircle, 
  CheckCircle2, 
  Zap,
  Activity,
  Maximize2,
  Search,
  Filter,
  Check,
  ChevronDown
} from 'lucide-react';
import { WallpaperSlot, AerialVideo } from '../types.js';

interface SlotBoardProps {
  slots: WallpaperSlot[];
  library: AerialVideo[];
  selectedSlot: WallpaperSlot | null;
  onSelectSlot: (slot: WallpaperSlot) => void;
  onApply: (slotUuid: string, videoUuid: string) => void;
  onRestore: (slotUuid: string) => void;
}

export default function SlotBoard({ 
  slots, 
  library, 
  selectedSlot, 
  onSelectSlot, 
  onApply, 
  onRestore 
}: SlotBoardProps) {
  const [activeReplaceSlotId, setActiveReplaceSlotId] = useState<string | null>(null);
  const [slotSearch, setSlotSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Custom Only' | 'Landscape' | 'Earth' | 'Space' | 'Cityscape'>('All');
  const [hoveredSlotVideoUrl, setHoveredSlotVideoUrl] = useState<string | null>(null);
  const [draggedOverSlotId, setDraggedOverSlotId] = useState<string | null>(null);

  const getCustomLabel = (slotName: string) => {
    const match = slotName.match(/\((.*?)\)/);
    return match ? match[1] : null;
  };

  // Drag & Drop handlers
  const handleDragOver = (e: React.DragEvent, slotId: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
    if (draggedOverSlotId !== slotId) {
      setDraggedOverSlotId(slotId);
    }
  };

  const handleDragLeave = () => {
    setDraggedOverSlotId(null);
  };

  const handleDrop = (e: React.DragEvent, slotId: string) => {
    e.preventDefault();
    setDraggedOverSlotId(null);
    const videoUuid = e.dataTransfer.getData("videoUuid");
    if (videoUuid) {
      onApply(slotId, videoUuid);
    }
  };

  // Filter & search slots
  const filteredSlots = slots.filter(slot => {
    const customLabel = getCustomLabel(slot.name);
    const matchesSearch = slot.name.toLowerCase().includes(slotSearch.toLowerCase()) || 
                          slot.category.toLowerCase().includes(slotSearch.toLowerCase()) ||
                          slot.originalVideoName.toLowerCase().includes(slotSearch.toLowerCase());
    
    if (categoryFilter === 'All') return matchesSearch;
    if (categoryFilter === 'Custom Only') return matchesSearch && !!customLabel;
    return matchesSearch && slot.category === categoryFilter;
  });

  return (
    <div className="flex flex-col gap-4" id="slots-manager-board">
      
      {/* Search and Category Filter Toolbar for Slots */}
      <div className="flex flex-col gap-2.5 bg-slate-900/60 p-3.5 rounded-2xl border border-slate-900">
        <label className="text-[10px] font-black tracking-wider uppercase text-slate-400 block mb-1">
          Search & Organize Lock Screen Slots
        </label>
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4.5 h-4.5 text-slate-500" />
            <input
              type="text"
              value={slotSearch}
              onChange={(e) => setSlotSearch(e.target.value)}
              placeholder="Search Apple wallpaper slots (e.g., Maui...)"
              className="w-full bg-slate-950 border border-slate-800 text-white placeholder-slate-500 rounded-xl py-2 pl-9 pr-3 text-xs focus:outline-none focus:ring-1 focus:ring-sky-500 transition"
              id="slot-input-search"
            />
          </div>

          <div className="flex flex-wrap gap-1">
            {(['All', 'Custom Only', 'Landscape', 'Earth', 'Space', 'Cityscape'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition duration-250 ${
                  categoryFilter === cat 
                    ? 'bg-indigo-600 text-white shadow-md' 
                    : 'bg-slate-950 text-slate-400 border border-slate-800/80 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Target Slot Droppable Grid */}
      {filteredSlots.length === 0 ? (
        <div className="bg-slate-900/10 border border-slate-900 border-dashed rounded-2xl p-8 text-center text-slate-500 text-xs">
          <Layers className="w-6 h-6 mx-auto mb-2 text-slate-705" />
          <p>No matching wallpaper slots discovered.</p>
          <span className="text-[9px] text-slate-650">Refine search criteria or select another filter tag.</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredSlots.map(slot => {
            const customLabel = getCustomLabel(slot.name);
            const isSelected = selectedSlot?.uuid === slot.uuid;
            const isDraggedOver = draggedOverSlotId === slot.uuid;
            
            return (
              <div
                key={slot.uuid}
                onClick={() => onSelectSlot(slot)}
                onDragOver={(e) => handleDragOver(e, slot.uuid)}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, slot.uuid)}
                className={`group border rounded-2xl p-4 transition-all duration-300 flex flex-col justify-between cursor-pointer relative overflow-hidden ${
                  isDraggedOver 
                    ? 'border-indigo-500 bg-indigo-950/20 ring-2 ring-indigo-500 shadow-indigo-500/10 scale-[1.01]' 
                    : isSelected 
                      ? 'border-sky-500 bg-sky-950/15 shadow-xl ring-1 ring-sky-500' 
                      : 'border-slate-800/90 bg-slate-950/95 hover:border-slate-750 hover:bg-slate-900/40'
                }`}
                id={`slot-card-${slot.uuid}`}
              >
                {/* Drag Drop Invitation Overlay */}
                {isDraggedOver && (
                  <div className="absolute inset-0 bg-indigo-950/40 backdrop-blur-xs flex flex-col items-center justify-center text-center z-20 pointer-events-none">
                    <Zap className="w-7 h-7 text-indigo-400 animate-bounce mb-1" />
                    <span className="text-xs font-black text-white">DROP HERE TO APPLY</span>
                    <span className="text-[9px] text-indigo-300">Sets customized lock screen loop</span>
                  </div>
                )}

                <div>
                  {/* Category and Slot Label Header */}
                  <div className="flex justify-between items-start gap-2 mb-2 relative">
                    <div className="flex flex-col min-w-0">
                      <span className="text-[9px] font-black uppercase text-sky-400 tracking-wider font-mono">
                        {slot.category} Slot
                      </span>
                      <h4 className="text-xs font-extrabold text-slate-100 truncate mt-0.5 leading-tight" title={slot.name}>
                        {slot.name.split(' (')[0]}
                      </h4>
                    </div>

                    <span className={`text-[8.5px] px-2 py-0.5 rounded-full font-bold uppercase shrink-0 border ${
                      customLabel 
                        ? 'bg-amber-500/10 text-amber-300 border-amber-500/20' 
                        : 'bg-emerald-500/5 text-slate-400 border-slate-800'
                    }`}>
                      {customLabel ? 'Customized' : 'System Default'}
                    </span>
                  </div>

                  {/* Slot Video Preview Area (Live Hover preview) */}
                  <div 
                    className="relative h-20 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden mt-2.5 mb-3 select-none"
                    onMouseEnter={() => setHoveredSlotVideoUrl(slot.videoUrl)}
                    onMouseLeave={() => setHoveredSlotVideoUrl(null)}
                  >
                    {hoveredSlotVideoUrl === slot.videoUrl ? (
                      <video
                        className="absolute inset-0 w-full h-full object-cover z-10 pointer-events-none"
                        autoPlay
                        loop
                        muted
                        src={slot.videoUrl}
                      />
                    ) : (
                      <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 to-slate-900 flex items-center justify-center opacity-65 group-hover:opacity-85 transition">
                        <Activity className="w-4 h-4 text-slate-650 animate-pulse" />
                        <span className="text-[8.5px] text-slate-500 font-mono ml-1.5 uppercase font-black">Hover to Play</span>
                      </div>
                    )}

                    <div className="absolute bottom-1.5 left-2 bg-black/75 backdrop-blur px-1.5 py-0.5 rounded text-[8.5px] text-slate-300 font-mono z-15">
                      {slot.resolution} ({slot.codec})
                    </div>
                  </div>

                  {/* Active Screen label */}
                  {customLabel ? (
                    <div className="bg-amber-500/5 border border-amber-500/10 p-2 rounded-lg flex items-center gap-2 mb-2 select-text">
                      <Video className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="text-[8px] font-medium text-slate-500 block uppercase tracking-wider font-sans">Custom Lock Screen Wallpaper:</span>
                        <span className="text-[10px] font-bold text-amber-200 truncate block leading-tight">{customLabel}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-slate-900/30 border border-dashed border-slate-850 p-2 rounded-lg text-center text-slate-500 text-[9px] font-semibold mb-2">
                      Displays original pristine Apple video loop
                    </div>
                  )}

                  {/* Apple Backup Link Info */}
                  <div className="text-[9px] text-slate-500 leading-normal flex items-center gap-1">
                    <span className="text-slate-600">Stock Name:</span>
                    <span className="font-mono text-[8.5px] text-slate-400 truncate flex-1 block font-medium">
                      {slot.originalVideoName}
                    </span>
                  </div>
                </div>

                {/* Swap mapping option & rollbacks */}
                <div 
                  className="mt-4 pt-2 border-t border-slate-900 flex items-center gap-1.5"
                  onClick={(e) => e.stopPropagation()} // block navigation trigger
                >
                  <div className="relative flex-1">
                    <button
                      onClick={() => setActiveReplaceSlotId(activeReplaceSlotId === slot.uuid ? null : slot.uuid)}
                      className="w-full bg-slate-900 hover:bg-slate-850 border border-slate-805 text-slate-200 py-1.5 px-2.5 rounded-xl text-[10px] font-bold transition flex items-center justify-between gap-1"
                      id={`replace-trigger-${slot.uuid}`}
                    >
                      <span className="text-slate-300">Set video...</span>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-500 group-hover:text-white" />
                    </button>

                    {activeReplaceSlotId === slot.uuid && (
                      <div className="absolute left-0 right-0 bottom-full mb-2 bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-50 max-h-52 overflow-y-auto divide-y divide-slate-900">
                        <div className="bg-slate-900 px-3 py-1.5 text-[9px] font-black tracking-wider text-slate-400 uppercase flex justify-between select-none">
                          <span>Select Library Video</span>
                          <span className="text-sky-400">Map Click</span>
                        </div>
                        {library.length === 0 ? (
                          <div className="p-4 text-center text-slate-650 text-[10px]">
                            Custom archives empty! Upload standard videos in Library Panel or Drag & Drop above.
                          </div>
                        ) : (
                          library.map(libVideo => (
                            <button
                              key={libVideo.uuid}
                              onClick={() => {
                                onApply(slot.uuid, libVideo.uuid);
                                setActiveReplaceSlotId(null);
                              }}
                              className="w-full text-left py-2 px-3 hover:bg-slate-900 transition flex justify-between items-center"
                            >
                              <div className="truncate pr-1.5">
                                <span className="text-xs font-extrabold text-white block truncate">
                                  {libVideo.name}
                                </span>
                                <span className="text-[8.5px] font-mono text-slate-500 truncate block">
                                  {libVideo.filename}
                                </span>
                              </div>
                              <span className="text-[7.5px] font-black tracking-widest px-1.5 py-0.5 rounded uppercase font-mono shrink-0 bg-slate-900 text-sky-400">
                                {libVideo.codec}
                              </span>
                            </button>
                          ))
                        )}
                      </div>
                    )}
                  </div>

                  {customLabel && (
                    <button
                      onClick={() => onRestore(slot.uuid)}
                      className="bg-red-950/15 hover:bg-red-900/25 border border-red-900/35 text-red-400 py-1.5 px-3 rounded-xl text-[10.5px] font-bold transition flex items-center gap-1 shrink-0"
                      title="Rollback custom video changes, restore Apple default backup screensaver file"
                      id={`restore-trigger-${slot.uuid}`}
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Stock Reset</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
