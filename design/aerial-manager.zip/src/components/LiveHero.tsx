/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Laptop, 
  Lock, 
  Unlock, 
  Clock, 
  HelpCircle,
  Wifi,
  Battery,
  Maximize2,
  Minimize2,
  Activity
} from 'lucide-react';
import { WallpaperSlot } from '../types.js';

interface LiveHeroProps {
  activeSlot: WallpaperSlot | null;
  slots: WallpaperSlot[];
  onSelectSlot: (slot: WallpaperSlot) => void;
}

export default function LiveHero({ activeSlot, slots, onSelectSlot }: LiveHeroProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [passcode, setPasscode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isImmersive, setIsImmersive] = useState(false);
  const [unlockFeedback, setUnlockFeedback] = useState<'idle' | 'success' | 'error'>('idle');

  // Time dynamic ticker
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  };

  const handlePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode === '2026' || passcode.length >= 4) {
      setUnlockFeedback('success');
      setTimeout(() => {
        setIsUnlocked(true);
        setUnlockFeedback('idle');
        setPasscode('');
      }, 600);
    } else {
      setUnlockFeedback('error');
      setTimeout(() => setUnlockFeedback('idle'), 800);
    }
  };

  const relock = () => {
    setIsUnlocked(false);
  };

  // Safe fallback if there's no active video or slot selected
  const displaySlot = activeSlot || slots[0];
  const videoUrl = displaySlot?.videoUrl;

  return (
    <div 
      id="live-screen-simulator"
      className={`relative rounded-3xl overflow-hidden shadow-2xl transition-all duration-700 border border-slate-800 bg-black ${
        isImmersive ? 'fixed inset-0 z-50 rounded-none' : 'aspect-video w-full'
      }`}
    >
      {/* Dynamic Video Loop Background */}
      {videoUrl ? (
        <video
          key={videoUrl}
          className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none transition-all duration-700"
          autoPlay
          loop
          muted
          playsInline
        >
          <source src={videoUrl} type="video/mp4" />
        </video>
      ) : (
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-indigo-950 flex flex-col items-center justify-center">
          <Activity className="w-12 h-12 text-slate-500 animate-pulse mb-3" />
          <p className="text-sm font-mono text-slate-400">Loading macOS Aerial Engine...</p>
        </div>
      )}

      {/* Glassmorphic Shadow Overlay */}
      <div className={`absolute inset-0 bg-black/25 transition-opacity duration-500 ${isUnlocked ? 'bg-black/60' : ''}`} />

      {/* Lock Screen Interface */}
      {!isUnlocked ? (
        <div className="absolute inset-0 flex flex-col justify-between p-6 md:p-8 text-white">
          {/* Top Indicators Bar */}
          <div className="flex justify-between items-center bg-transparent drop-shadow-md z-10">
            <div className="flex items-center gap-1.5 backdrop-blur-md bg-white/10 px-3 py-1 rounded-full text-xs font-medium border border-white/10">
              <Laptop className="w-3.5 h-3.5 text-sky-400" />
              <span>macOS Tahoe Lock Screen Simulator</span>
            </div>
            <div className="flex items-center gap-3 backdrop-blur-md bg-white/10 px-3 py-1 rounded-full text-xs font-semibold border border-white/10">
              <span className="text-[10px] bg-sky-500/30 px-1.5 py-0.5 rounded text-sky-300 uppercase tracking-wider font-mono">Live Slot</span>
              <span className="truncate max-w-[120px] text-slate-200">
                {displaySlot ? displaySlot.name.split(' (')[0] : 'Scanning...'}
              </span>
              <span className="text-slate-400">|</span>
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Clock Section (Center of Tahoe Locks) */}
          <div className="flex flex-col items-center text-center mt-4 md:mt-8 select-none z-10 animate-fade-in">
            <h1 className="text-7xl md:text-8xl font-sans font-light tracking-tight text-white drop-shadow-xl select-all select-none">
              {formatTime(currentTime)}
            </h1>
            <p className="text-sm md:text-base font-semibold tracking-wide text-white/95 mt-2 drop-shadow-md">
              {formatDate(currentTime)}
            </p>
          </div>

          {/* User Signin / Unlock (Bottem-Center-ish) */}
          <div className="flex flex-col items-center justify-center mb-6 md:mb-10 z-10">
            <form onSubmit={handlePasscodeSubmit} className="flex flex-col items-center">
              {/* Avatar Frame */}
              <div className="relative group mb-3 shadow-lg">
                <div className="absolute -inset-1 rounded-full bg-gradient-to-tr from-sky-400 to-indigo-500 blur opacity-40 group-hover:opacity-70 transition duration-300" />
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
                  alt="macOS Profile"
                  className="relative w-16 h-16 rounded-full border border-white/30 object-cover"
                />
                <div className="absolute -bottom-1 -right-1 bg-sky-500 text-white rounded-full p-1 border border-slate-900 shadow">
                  <Lock className="w-3 h-3" />
                </div>
              </div>

              <span className="font-semibold text-sm drop-shadow-md mb-2">Steve KKimm</span>

              {/* Enter Passcode input */}
              <div className={`relative flex items-center transition-all duration-300 ${
                unlockFeedback === 'error' ? 'animate-shake' : ''
              }`}>
                <input
                  type="password"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder="Enter passcode (try '2026')"
                  className={`w-44 px-3.5 py-1.5 text-center text-xs rounded-full bg-black/40 text-white placeholder-white/50 border backdrop-blur-xl focus:outline-none focus:ring-1 focus:ring-white/40 transition ${
                    unlockFeedback === 'error' ? 'border-red-500 bg-red-950/20' : 
                    unlockFeedback === 'success' ? 'border-emerald-500 bg-emerald-950/20' : 'border-white/10'
                  }`}
                  id="simulator-passcode-input"
                />
                <button 
                  type="submit"
                  className="absolute right-2 top-1.5 p-0.5 rounded-full hover:bg-white/25 transition"
                  aria-label="Unlock"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-white/70" />
                </button>
              </div>
            </form>
          </div>

          {/* Bottom Screen Utility HUD */}
          <div className="flex justify-between items-center text-xs text-white/70 font-medium z-10">
            <div>
              <span>Press <b>ESC</b> or passcode <b>2026</b> to unlock</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsImmersive(!isImmersive)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/25 border border-white/10 text-white font-medium z-10 transition duration-200"
              >
                {isImmersive ? (
                  <>
                    <Minimize2 className="w-3.5 h-3.5" />
                    <span>Exit Immersive</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>Fullscreen Immersive</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Unlocked Screen / macOS Desktop Mock with Controls */
        <div className="absolute inset-0 bg-slate-900/10 backdrop-blur-lg flex flex-col justify-between p-6 md:p-8 text-white z-10 animate-fade-in">
          {/* Menu Bar */}
          <div className="flex justify-between items-center text-xs text-slate-100 font-semibold drop-shadow">
            <div className="flex items-center gap-4">
              <span className="font-bold"></span>
              <span className="text-white">Finder</span>
              <span className="text-slate-200/80">File</span>
              <span className="text-slate-200/80">Edit</span>
              <span className="text-slate-200/80">View</span>
              <span className="text-slate-200/80">Go</span>
            </div>
            <div className="flex items-center gap-3">
              <Wifi className="w-3.5 h-3.5" />
              <span>Wednesday 5:44 AM</span>
            </div>
          </div>

          {/* Centered Desktop HUD card */}
          <div className="flex flex-col items-center justify-center my-auto">
            <div className="max-w-md w-full bg-slate-900/85 border border-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-2xl text-center">
              <Unlock className="w-10 h-10 text-emerald-400 mx-auto mb-3 animate-bounce" />
              <h3 className="text-lg font-bold">macOS Tahoe Unlocked</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Your bespoke Aerial screensaver is applied. Notice the gorgeous loop backing behind your floating applications! When the Mac idling triggers the Lock Screen, this cinematic render will display.
              </p>

              {/* Grid of details */}
              <div className="mt-4 border-t border-white/5 pt-4 text-left grid grid-cols-2 gap-3 text-[11px]">
                <div>
                  <span className="text-slate-400 block font-light">Active Slot:</span>
                  <span className="text-white font-medium truncate block">
                    {displaySlot ? displaySlot.originalVideoName : 'None'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-light">Custom Video:</span>
                  <span className="text-sky-300 font-medium truncate block">
                    {displaySlot && displaySlot.activeVideoId ? displaySlot.name.replace(/.*?\((.*?)\)/, '$1') : 'Default Stock Video'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block font-light">Resolution:</span>
                  <span className="text-white font-medium">{displaySlot?.resolution}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-light">Codec Stream:</span>
                  <span className="text-emerald-400 font-medium font-mono">{displaySlot?.codec}</span>
                </div>
              </div>

              <div className="mt-5 flex gap-2">
                <button
                  type="button"
                  onClick={relock}
                  className="flex-1 bg-white text-slate-950 hover:bg-slate-150 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Lock Screen</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsImmersive(!isImmersive)}
                  className="flex-1 bg-slate-800 text-white hover:bg-slate-700 py-2 rounded-xl text-xs font-bold transition border border-white/10 flex items-center justify-center gap-1.5"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Toggle Fullscreen</span>
                </button>
              </div>
            </div>
          </div>

          {/* Desktop Dock Mockup */}
          <div className="mx-auto bg-slate-950/40 backdrop-blur-2xl border border-white/10 py-1.5 px-3 rounded-2xl flex gap-3 shadow-lg max-w-sm">
            {slots.map(s => {
              const fileId = s.activeVideoId;
              const isSelected = displaySlot?.uuid === s.uuid;
              return (
                <button
                  key={s.uuid}
                  onClick={() => onSelectSlot(s)}
                  className={`text-[10px] w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                    isSelected ? 'bg-sky-500 text-white ring-2 ring-white/50 scale-110' : 
                    fileId ? 'bg-amber-600/60 text-amber-200 hover:bg-amber-600/80' : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                  title={`Slot Desk Key: ${s.name}`}
                >
                  <span className="font-bold font-mono">{s.name.substring(0,2).toUpperCase()}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// Inline minimalist svg icon to avoid extra deps
function ChevronRight({ className }: { className: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
  );
}
