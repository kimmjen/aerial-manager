/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  UploadCloud, 
  Trash2, 
  Edit2, 
  Check, 
  Video, 
  ChevronDown, 
  Calendar, 
  Cpu, 
  HardDrive,
  Sparkles,
  RefreshCw,
  Play,
  GripVertical
} from 'lucide-react';
import { AerialVideo, WallpaperSlot } from '../types.js';

interface LibraryPanelProps {
  videos: AerialVideo[];
  slots: WallpaperSlot[];
  onApply: (slotUuid: string, videoUuid: string) => void;
  onUpload: (name: string, filename: string, base64: string) => Promise<void>;
  onRename: (uuid: string, newName: string) => void;
  onDelete: (uuid: string) => void;
}

export default function LibraryPanel({ 
  videos, 
  slots, 
  onApply, 
  onUpload, 
  onRename, 
  onDelete 
}: LibraryPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [codecFilter, setCodecFilter] = useState<'All' | 'HEVC' | 'H.264' | 'AV1'>('All');
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  
  // Stats
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [dragActive, setDragActive] = useState(false);

  // Inline rename state
  const [renamingVideoId, setRenamingVideoId] = useState<string | null>(null);
  const [tempName, setTempName] = useState('');

  // Hover preview target
  const [hoveredVideoUrl, setHoveredVideoUrl] = useState<string | null>(null);

  // Filter & Search
  const filteredVideos = videos.filter(v => {
    const matchesSearch = v.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          v.filename.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCodec = codecFilter === 'All' || v.codec === codecFilter;
    return matchesSearch && matchesCodec;
  });

  // Handle file import
  const processFile = (file: File) => {
    if (!file) return;
    setIsUploading(true);
    setUploadProgress(15);

    const reader = new FileReader();
    reader.onload = async (e) => {
      setUploadProgress(65);
      const dataUrl = e.target?.result as string;
      if (!dataUrl) {
        setIsUploading(false);
        alert('Failed to read file buffer.');
        return;
      }
      
      const base64Content = dataUrl.split(',')[1];
      setUploadProgress(85);

      try {
        const cleanName = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
        await onUpload(cleanName, file.name, base64Content);
        setUploadProgress(100);
        setTimeout(() => {
          setIsUploading(false);
          setUploadProgress(0);
        }, 500);
      } catch (err) {
        console.error(err);
        setIsUploading(false);
        setUploadProgress(0);
      }
    };

    reader.onerror = () => {
      setIsUploading(false);
      alert('Error reading files.');
    };

    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const startRename = (video: AerialVideo) => {
    setRenamingVideoId(video.uuid);
    setTempName(video.name);
  };

  const saveRename = (uuid: string) => {
    if (tempName.trim()) {
      onRename(uuid, tempName.trim());
    }
    setRenamingVideoId(null);
  };

  const formatSize = (bytes: number) => {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Drag start handler for video cards
  const handleCardDragStart = (e: React.DragEvent, videoUuid: string) => {
    e.dataTransfer.setData("videoUuid", videoUuid);
    e.dataTransfer.effectAllowed = "copy";
  };

  return (
    <div className="flex flex-col gap-5" id="media-library-panel">
      
      {/* Search and Upload Controls */}
      <div className="flex flex-col md:flex-row gap-3.5 justify-between items-stretch">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search custom library videos..."
            className="w-full bg-slate-900 border border-slate-800/80 text-white placeholder-slate-500 rounded-xl py-2 pl-9 pr-3 text-xs focus:outline-none focus:ring-1 focus:ring-sky-500 transition"
          />
        </div>

        {/* Codec filters */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800/80 self-start shrink-0">
          {(['All', 'HEVC', 'H.264', 'AV1'] as const).map(f => (
            <button
              key={f}
              onClick={() => setCodecFilter(f)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition duration-200 ${
                codecFilter === f 
                  ? 'bg-sky-500 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Drag & Drop Upload Uploader Box */}
      <div 
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-2xl p-4 text-center transition duration-200 ${
          dragActive ? 'border-sky-500 bg-sky-950/10' : 'border-slate-800 bg-slate-900/10 hover:bg-slate-900/20'
        }`}
      >
        <input 
          type="file" 
          accept="video/*" 
          onChange={handleFileChange} 
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
          disabled={isUploading}
          id="upload-file-picker-input"
        />
        
        {isUploading ? (
          <div className="flex flex-col items-center py-2">
            <RefreshCw className="w-6 h-6 text-sky-400 animate-spin mb-2" />
            <span className="text-[11px] font-semibold text-white">Uploading & Analyzing Buffer...</span>
            <div className="w-48 bg-slate-950 h-1 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-sky-500 h-1 rounded-full transition-all duration-300" 
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            <span className="text-[9px] font-mono text-slate-500 mt-1">{uploadProgress}% Complete</span>
          </div>
        ) : (
          <div className="flex flex-col items-center py-1.5">
            <UploadCloud className="w-6 h-6 text-sky-400 mb-1.5" />
            <h4 className="text-[11px] font-bold text-slate-200">Drag & drop video clip or click to browse</h4>
            <p className="text-[9px] text-slate-500 mt-0.5">
              Lossless copy for H.264/HEVC. Automatic transcode pipeline for MKV/WebM/AV1.
            </p>
          </div>
        )}
      </div>

      {/* Videos List Grid */}
      {filteredVideos.length === 0 ? (
        <div className="bg-slate-900/10 border border-slate-900 rounded-3xl p-8 text-center text-slate-500">
          <Video className="w-8 h-8 text-slate-850 mx-auto mb-2" />
          <p className="text-xs">No library videos found</p>
          <span className="text-[9px] text-slate-700 block mt-0.5">Drop raw file or customize filter tags above</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredVideos.map(video => {
            const isSeed = video.uuid.startsWith('seed-');
            const isRenaming = renamingVideoId === video.uuid;
            
            return (
              <div
                key={video.uuid}
                draggable={true}
                onDragStart={(e) => handleCardDragStart(e, video.uuid)}
                className="group relative bg-slate-950 border border-slate-850 rounded-2xl overflow-hidden hover:border-slate-700 hover:shadow-xl transition-all duration-300 flex flex-col cursor-grab active:cursor-grabbing"
              >
                {/* Thumbnail Header with Drag Handle */}
                <div id={`clip-card-header-${video.uuid}`} className="relative h-28 w-full bg-slate-900 border-b border-slate-950 overflow-hidden">
                  
                  {/* Dynamic Hover Preview (HoverVideo Feature) */}
                  {hoveredVideoUrl === video.filepath ? (
                    <video
                      className="absolute inset-0 w-full h-full object-cover z-20 pointer-events-none"
                      autoPlay
                      loop
                      muted
                      src={video.filepath}
                    />
                  ) : video.thumbnailUrl ? (
                    <img
                      src={video.thumbnailUrl}
                      alt={video.name}
                      className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-102 transition-transform duration-500"
                    />
                  ) : (
                    <div className="absolute inset-0 bg-slate-900 flex items-center justify-center">
                      <Play className="w-4 h-4 text-slate-700 group-hover:scale-110 transition duration-300" />
                    </div>
                  )}

                  {/* Drag Indicator Tooltip on Thumbnail */}
                  <div className="absolute inset-0 bg-black/45 backdrop-blur-3xs opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center z-10 text-center">
                    <GripVertical className="w-5 h-5 text-sky-400 mb-1" />
                    <span className="text-[9px] font-black uppercase tracking-wider text-white">DRAG CARD TO WALLPAPER SLOT</span>
                    <span className="text-[8px] text-slate-400">or click Apply below</span>
                  </div>

                  {/* Quality & duration tags */}
                  <div className="absolute top-2 left-2.5 flex items-center gap-1 z-30">
                    <span className="text-[8px] font-black tracking-widest bg-slate-950/90 text-sky-400 px-2 py-0.5 rounded-full border border-sky-950/20 uppercase font-mono">
                      {video.codec}
                    </span>
                    <span className="text-[8.5px] font-bold bg-slate-950/90 text-slate-300 px-2 py-0.5 rounded-full border border-slate-900">
                      {video.resolution}
                    </span>
                  </div>

                  <div className="absolute bottom-2 left-2.5 bg-black/85 backdrop-blur-md px-1.5 py-0.5 rounded text-[8.5px] text-white font-mono z-30 font-medium">
                    {video.duration}s Loop
                  </div>
                  
                  <div className="absolute bottom-2 right-2.5 bg-black/85 backdrop-blur-md px-1.5 py-0.5 rounded text-[8.5px] text-white font-mono z-30 font-medium">
                    {formatSize(video.fileSize)}
                  </div>
                </div>

                {/* Card Title & Info */}
                <div className="p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    {isRenaming ? (
                      <div className="flex items-center gap-1.5 mb-2" id={`rename-panel-${video.uuid}`}>
                        <input
                          type="text"
                          value={tempName}
                          onChange={(e) => setTempName(e.target.value)}
                          className="flex-1 bg-slate-905 border border-slate-700 text-white rounded px-2 py-1 text-xs font-bold focus:outline-none"
                          onKeyDown={(e) => e.key === 'Enter' && saveRename(video.uuid)}
                        />
                        <button
                          onClick={() => saveRename(video.uuid)}
                          className="bg-sky-500 text-white rounded p-1.5 hover:bg-sky-400 text-xs font-bold"
                          title="Save Name"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex justify-between items-start gap-1 pb-0.5">
                        <h4 className="text-xs font-bold text-slate-100 truncate flex-1 leading-normal" title={video.name}>
                          {video.name}
                        </h4>
                        {!isSeed && (
                          <button
                            onClick={() => startRename(video)}
                            className="text-slate-500 hover:text-white p-0.5 rounded transition"
                            title="Edit Title"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    )}
                    <span className="text-[9px] font-mono text-slate-500 block truncate" title={video.filename}>
                      {video.filename}
                    </span>
                  </div>

                  {/* Apply Dropdown & Delete Options */}
                  <div className="mt-3.5 pt-2 border-t border-slate-900 flex items-center gap-1.5 relative">
                    
                    {/* Choose Target Slot Button */}
                    <div className="relative flex-1">
                      <button
                        onClick={() => setActiveDropdown(activeDropdown === video.uuid ? null : video.uuid)}
                        className="w-full bg-slate-900 hover:bg-slate-850 border border-slate-805 text-white py-1.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-between gap-1"
                        id={`apply-dropdown-trigger-${video.uuid}`}
                      >
                        <span className="text-sky-400 text-[9px] uppercase font-black tracking-wider">Quick Apply To</span>
                        <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                      </button>

                      {activeDropdown === video.uuid && (
                        <div className="absolute left-0 right-0 bottom-full mb-1 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-40 max-h-44 overflow-y-auto divide-y divide-slate-900">
                          {slots.map(slot => (
                            <button
                              key={slot.uuid}
                              onClick={() => {
                                onApply(slot.uuid, video.uuid);
                                setActiveDropdown(null);
                              }}
                              className="w-full text-left py-2 px-3 text-slate-300 hover:text-white hover:bg-slate-900 text-xs transition font-semibold flex items-center justify-between"
                            >
                              <span className="truncate pr-1">{slot.name.split(' (')[0]}</span>
                              <span className="text-[7.5px] tracking-wider font-extrabold uppercase text-slate-500 shrink-0 font-mono">
                                {slot.category}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Delete Custom Video Trash Can */}
                    {!isSeed && (
                      <button
                        onClick={() => onDelete(video.uuid)}
                        className="bg-red-950/15 hover:bg-red-900/25 border border-red-900/35 text-red-400 p-1.5 rounded-xl transition shrink-0"
                        title="Delete video from custom catalog"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
